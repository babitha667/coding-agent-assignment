"""Time-aware solver limits and checkpoints, never permission to grade bad code."""


def allowances(state):
    # Keep short local experiments proportional instead of reserving 600s in a
    # 60s task. Production 1800s tasks retain 300s + 300s planning allowances.
    return (min(state.config.grading_reserve_s, state.config.task_timeout_s / 6),
            min(state.config.repair_reserve_s, state.config.task_timeout_s / 6))


def request_limits(state, role, output_limit):
    cfg, remaining = state.config, state.remaining_s
    timeout = min(cfg.api_timeout_s, max(1, remaining))
    if role != 'solver':
        return output_limit, timeout
    output_limit = min(output_limit, cfg.solver_turn_output_tokens)
    grading, repair = allowances(state)
    reserve = grading + (repair if not state.grades else 0)
    if remaining <= reserve:
        output_limit = min(output_limit, cfg.late_solver_output_tokens)
        timeout = min(timeout, 30 if remaining <= grading else 60)
    else:
        timeout = min(timeout, max(1, remaining-reserve))
    return output_limit, timeout


def deadline_message(state):
    cfg, remaining = state.config, state.remaining_s
    elapsed = cfg.task_timeout_s - remaining
    grading, repair = allowances(state)
    reserve = grading + (repair if not state.grades else 0)
    stage = ('final_validation' if remaining <= grading else
             'validation_and_feedback' if remaining <= reserve else
             'first_candidate_due' if not state.grades and elapsed >= cfg.first_grade_target_s else '')
    if not stage or state.deadline_stage == stage:
        return None
    state.deadline_stage = stage
    state.log('time_checkpoint', stage=stage, remaining_s=round(remaining), reserve_s=reserve)
    return (f'TIME CHECKPOINT: {round(remaining)}s remain. Aim for the first complete, verified candidate '
        f'by {cfg.first_grade_target_s}s; allow about {cfg.grading_reserve_s}s for grading and '
        f'{cfg.repair_reserve_s}s for Expert-guided repair. These are planning allowances, not guaranteed '
        'grader durations. Stop broad investigation; implement the supported fix, run focused real '
        'regressions and repository-correct build checks, then submit immediately when complete. '
        'Do not repeat unchanged passing checks, optimize unrelated code or weaken tests to meet a timer. '
        'After verification passes, call submit as the NEXT action. A blocked submit needs another '
        'explicit submit after its checks are fixed; checks and timers never submit for you. '
        'Never submit an unfinished/unverified patch just because time is short.')
