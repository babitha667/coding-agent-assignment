"""Focused solver tools. Source access always goes through the task sandbox."""

import json
import inspect
import posixpath
import re
import shlex
from copy import deepcopy

from .code_checks import static_checks
from .task_state import as_items
from .regressions import RegressionGuard
from .validation import classify, masks_status, test_failure_reason, project_validation_info


def function(name, description, properties, required=()):
    return {"type": "function", "function": {"name": name, "description": description,
        "parameters": {"type": "object", "properties": properties, "required": list(required)}}}


READ = function("read_files", "Read several repository files/ranges. Returned next_start_line and pending "
                "requests identify omitted content; never assume a truncated read was complete.", {
    "requests": {"type": "array", "items": {"type": "object", "properties": {
        "path": {"type": "string"}, "start_line": {"type": "integer"},
        "num_lines": {"type": "integer"}}, "required": ["path"]}}}, ["requests"])
READ_ROUND = function('read_round', 'Read a specific past grading round from the task-private ledger. '
    'Diagnosis includes that round\'s findings, hypotheses, plan and reference cases; checks includes '
    'executed commands/results; review includes subsequent reviewer feedback; patch reads its actual '
    'archived candidate diff. Read-only, no hidden tests or filesystem paths accepted.', {
        'attempt': {'type': 'integer', 'minimum': 0},
        'section': {'type': 'string', 'enum': ['diagnosis', 'checks', 'review', 'patch']},
        'offset': {'type': 'integer', 'minimum': 0}}, ['attempt'])
NOTES = function("update_notes", "Update the shared notebook. Fields replace previous values; scenarios accumulate. "
    "Keep concise source-referenced observations separate from hypotheses. Record unresolved questions, "
    "the concrete next edits, and issue-specific corner cases with expected behavior; do not claim hidden "
    "tests or unexecuted checks passed. After failed grading, record repair_review: the earlier mistaken "
    "assumption, missed behavior, requirement-derived counterexample and concrete edits. After editing, "
    "set review to a concise assessment of the CURRENT patch against old and new scenarios. At a no-edit "
    "checkpoint, record next_step: a concrete implementation or ONE specific unresolved fact to inspect.", {
        "repo_map": {"type": "string"},
        **{key: {"type": "array", "items": {"type": "string"}} for key in
           ("findings", "hypotheses", "ruled_out", "open_questions", "plan", "scenarios",
            "requirements", "review_actions")},
        "review": {"type": "string"},
        "review_question": {"type": "string", "description": "Optional precise contradiction or missing evidence in the latest review, with requirement/source evidence. Requests at most one budgeted clarification for that review on unchanged source. Empty clears it."},
        "repair_review": {"type": "object", "properties": {
            "previous_assumption": {"type": "string"}, "missed_behavior": {"type": "string"},
            "planned_changes": {"type": "array", "items": {"type": "string"}, "minItems": 1, "maxItems": 6},
            "new_scenarios": {"type": "array", "minItems": 1, "maxItems": 4, "items": {
                "type": "object", "properties": {
                    "input": {"description": "Concrete input as JSON or concise text; empty values/null are valid."},
                    "expected": {"description": "Requirement-derived expected value as JSON or concise text."},
                    "previous_patch_behavior": {"type": "string"}, "requirement": {"type": "string"}},
                "required": ["input", "expected", "previous_patch_behavior", "requirement"]}}},
            "required": ["previous_assumption", "missed_behavior", "planned_changes", "new_scenarios"]},
        "next_step": {"type": "object", "properties": {
            "action": {"type": "string", "enum": ["implement", "inspect"]},
            **{key: {"type": "string"} for key in ("target", "reason", "change_or_question")}},
            "required": ["action", "target", "reason", "change_or_question"]}})
BASH = function("bash", "Run a focused inspection, edit or check in the task checkout. Batch related work. "
    "The shell is bash with pipefail. Each command starts in the repository directory; files persist, "
    "shell variables/cwd do not. Prefer coherent focused edits. In local_tests mode run the issue regression "
    "and relevant existing tests with purpose=test and covers=[all affected source/test paths]; this also "
    "counts as a smoke check. Inspect assertion failures and exit status, not merely printed values. "
    "For basic code readiness in BOTH modes, "
    "run focused execution with purpose=check, check_kind=smoke and covers=[repository-relative source paths]. "
    "For compiled sources/build manifests, also run the repository build with check_kind=build. "
    "Syntax checks, git diff, echo or merely claiming PASS are not smoke execution. A focused local test "
    "may also use check_kind=smoke plus covers. No network or hidden-test access.", {
        "command": {"type": "string"}, "timeout_s": {"type": "integer"},
        "check_kind": {"type": "string", "enum": ["smoke", "build"]},
        "covers": {"type": "array", "items": {"type": "string"}, "minItems": 1, "maxItems": 50},
        "purpose": {"type": "string", "enum": ["inspect", "edit", "check", "test"]}}, ["command"])
SUBMIT = function("submit", "Submit the current cumulative source patch for course grading. First reason "
    "through the issue-specific scenarios and inspect the diff. In local_tests mode execute the relevant "
    "tests first. Basic smoke/build checks must also succeed for the current patch in either mode. "
    "Call this tool alone. Hidden grading returns counts, NOT failed-test details.", {})

RUN_TESTS = function('run_tests', 'Execute issue regressions and relevant existing tests in the checkout. '
    'The harness records command, exit status, exact patch and test inventory automatically; no purpose '
    'or covers labels are needed. This is execution evidence, not proof of exhaustive coverage. '
    'New tests are optional. For an uncertain review finding, optionally run a requirement-derived '
    'counterexample with review_case=true before editing. A passing case disproves that proposed reproducer; '
    'a setup/import error does not reproduce the bug. Never remove valid old cases.', {
        'command': {'type': 'string'}, 'timeout_s': {'type': 'integer'},
        'review_case': {'type': 'boolean'},
        'test_corrections': {'type': 'array', 'items': {'type': 'object', 'properties': {
            key: {'type': 'string'} for key in ('path', 'before_sha256', 'after_sha256', 'requirement', 'reason')},
            'required': ['path', 'before_sha256', 'after_sha256', 'requirement', 'reason']}}}, ['command'])


def notes_tool(state):
    """Do not advertise failed-cycle fields before a failed cycle exists."""
    tool = deepcopy(NOTES)
    if not state.latest or not state.latest.grade['tests_failed']:
        tool['function']['parameters']['properties'].pop('repair_review', None)
    return tool


def is_test_command(command):
    """Recognize ordinary shell test invocations, not strings inside edit payloads.

    This is a convenience classifier, not a security parser. Explicit run_tests
    remains available for custom runners and complex shell scripts.
    """
    return classify(command)['test']


def python_command(script, *args):
    return "python3 -c " + shlex.quote(script) + " " + " ".join(shlex.quote(str(a)) for a in args)


# Read a range without transporting the whole file. realpath prevents symlink escape.
READ_SCRIPT = """
import hashlib,json,os,sys
root=os.path.realpath(sys.argv[1]); path=os.path.realpath(os.path.join(root,sys.argv[2]))
if os.path.commonpath([root,path]) != root: raise ValueError('Path is outside repository')
start,count,limit=map(int,sys.argv[3:]); h=hashlib.sha256(); total=0; rows=[]; used=0; next_line=None
with open(path,'rb') as stream:
 for total,line in enumerate(stream,1):
  h.update(line)
  if total < start or total >= start+count: continue
  value=line.decode('utf-8',errors='replace').rstrip('\\r\\n'); room=limit-used
  if len(value)+24 > room:
   if not rows and room>80:
    rows.append(str(total)+': '+value[:room-80]+' [LINE TRUNCATED; use bash for targeted extraction]')
   if next_line is None: next_line=total
   continue
  if next_line is not None: continue
  rows.append(str(total)+': '+value); used+=len(value)+24
if next_line is None and total >= start+count: next_line=start+count
print(json.dumps(dict(path=os.path.relpath(path,root),sha256=h.hexdigest(),start_line=start,
 end_line=(start+len(rows)-1),total_lines=total,content='\\n'.join(rows),next_start_line=next_line)))
"""

MAP_SCRIPT = """
import os,json
skip={'.git','node_modules','.venv','venv','vendor','__pycache__','.pytest_cache','dist','build'}
rows=[]; omitted=False
for root,dirs,files in os.walk('.'):
 dirs[:]=sorted(d for d in dirs if d not in skip)
 if root.count(os.sep)>=2: dirs[:]=[]
 for name in sorted(files):
  if len(rows)<160: rows.append(os.path.join(root,name))
  else: omitted=True
print(json.dumps({'files_depth_2':rows,'listing_incomplete':omitted,
 'note':'Shallow orientation only; use targeted bash searches for more files.'}))
"""


class TaskTools:
    def __init__(self, sandbox, state, config):
        self.sb, self.state, self.config = sandbox, state, config
        self.regressions = RegressionGuard(sandbox, state)
        self.inventory_patch = None
        self.validation_metadata = None

    def read_files(self, arguments):
        requests = arguments.get("requests", arguments.get("files"))
        if requests is None:
            requests = [arguments]  # Recover harmless flat-path formatting mistakes.
        requests = as_items(requests)
        results, pending, remaining = [], [], self.config.read_batch_chars
        for index, request in enumerate(requests):
            if remaining < 300 or index >= 20:
                pending.extend(requests[index:])
                break
            if isinstance(request, str):
                request = {"path": request}
            try:
                path = request["path"]
                if not isinstance(path, str) or not path.strip():
                    raise ValueError("A nonempty path is required")
                start = max(1, int(request.get("start_line", request.get("offset", 1))))
                wanted = max(1, int(request.get("num_lines", request.get("limit", self.config.read_default_lines))))
                count = min(wanted, self.config.read_max_lines)
                response = self.sb.exec(python_command(READ_SCRIPT, self.sb.workdir, path, start, count,
                                                       min(remaining, self.config.read_batch_chars)), timeout_s=60)
                if response["exit_code"] != 0 or response.get("timed_out"):
                    raise ValueError(response["output"][-1500:])
                result = json.loads(response["output"])
                result["requested_lines"] = wanted
                self.state.record_read(result["path"], result["sha256"], start,
                                       result["end_line"], result["content"])
            except (ValueError, KeyError, TypeError) as exc:
                result = {"request": request, "error": str(exc)}
            results.append(result)
            remaining -= len(json.dumps(result, ensure_ascii=False))
        self.state.save()
        return {"files": results, "pending_requests": pending,
                "note": "Use next_start_line or pending_requests when more source is needed."}

    def bash(self, arguments):
        command = arguments.get("command")
        if not isinstance(command, str) or not command.strip():
            raise ValueError("A nonempty command is required")
        inferred = classify(command)
        purpose = arguments.get('purpose', 'inspect')
        kind, covers = arguments.get("check_kind"), arguments.get("covers", [])
        if purpose not in ("inspect", "edit", "check", "test"):
            raise ValueError("purpose must be inspect, edit, check or test")
        if inferred['test']:
            purpose, kind = 'test', 'smoke'
        elif inferred['build']:
            purpose, kind = 'check', 'build'
        elif kind and 'purpose' not in arguments:
            purpose = 'check'
        if purpose == "test" and self.config.verification_mode == "local_tests":
            kind = kind or 'smoke'
            # Agent records the actual patch paths after execution, including new
            # test files. No extra compile/subprocess pass just to infer labels.
        if kind is not None:
            if kind not in ("smoke", "build") or purpose not in ("check", "test"):
                raise ValueError("check_kind requires purpose=check (or purpose=test for a local smoke test)")
            if kind == "build" and purpose != "check":
                raise ValueError("A build check requires purpose=check")
            if not isinstance(covers, list) or len(covers) > 50 or any(
                    not isinstance(path, str) or not path.strip() or posixpath.isabs(path)
                    or posixpath.normpath(path) in (".", "..")
                    or posixpath.normpath(path).startswith("../") for path in covers):
                raise ValueError("Readiness checks need covers=[repository-relative source paths]")
            covers = sorted({posixpath.normpath(path) for path in covers})
            if re.fullmatch(r"\s*(?:true|:|pwd|echo[^\n;&|]*|printf[^\n;&|]*|ls[^\n;&|]*|"
                            r"git\s+(?:diff|status|show)[^\n;&|]*|"
                            r"python[23]?\s+-m\s+(?:py_compile|compileall)[^\n;&|]*)\s*", command):
                raise ValueError("A readiness check must execute affected code or its build, not just print/inspect/compile syntax")
        # Workflow guard, NOT a shell security parser. Do not parse heredoc Python
        # or JS bodies as shell and accidentally reject valid multiline edits.
        obvious_test = is_test_command(command)
        if self.config.verification_mode == "reference" and (purpose == "test" or obvious_test):
            return {"error": "Reference mode: reason through scenarios; do not execute local tests. "
                             "Use submit for the real course grading."}
        if inferred['tsc'] and inferred['source_arguments'] and 'typescript' in self.validation_context():
            return {'error': 'This checkout has tsconfig.json. Passing source filenames to tsc ignores its settings. '
                    'Use the repository typecheck script or ./node_modules/.bin/tsc --project tsconfig.json --noEmit.',
                    'purpose': purpose, 'check_kind': kind, 'covers': covers}
        check = purpose in ('test', 'check')
        timeout = min(600, max(1, int(arguments.get('timeout_s', arguments.get('timeout', 120)))),
                      max(1, int(self.state.remaining_s)))
        # errexit preserves a failed check followed by '; echo EXIT:$?'. Shell
        # conditionals can suppress errexit, so obvious OR-masking is rejected too.
        if check and masks_status(command):
            return {'error': 'Check command masks failure status; run it directly without || or ignored status',
                    'purpose': purpose, 'check_kind': kind, 'covers': covers}
        result = self.sb.exec('bash ' + ('-e ' if check else '') + '-o pipefail -c ' + shlex.quote(command), timeout_s=timeout)
        result["purpose"] = purpose
        if purpose == 'test':
            reason = test_failure_reason(result, command)
            if reason:
                result['error'] = reason
        if kind is not None:
            result.update(check_kind=kind, covers=covers)
            result['check_kinds'] = sorted({kind} | ({'build'} if inferred['build'] else set()))
        if len(result.get("output", "")) > self.config.command_output_chars:
            output = result["output"]
            half = self.config.command_output_chars // 2
            result.update(output=output[:half] + "\n[OUTPUT TRUNCATED: narrow command or read a range]\n" + output[-half:],
                          original_output_chars=len(output), output_truncated=True)
        return result

    def validation_context(self):
        if self.validation_metadata is None:
            script = inspect.getsource(project_validation_info) + '\nimport json; print(json.dumps(project_validation_info()))'
            result = self.sb.exec(python_command(script), timeout_s=max(1, min(30, int(self.state.remaining_s))))
            try:
                self.validation_metadata = json.loads(result['output']) if result.get('exit_code') == 0 else {}
            except (ValueError, KeyError):
                self.validation_metadata = {}
        return self.validation_metadata

    def run_tests(self, arguments):
        if arguments.get('test_corrections'):
            self.regressions.capture()
            self.regressions.accept_corrections(arguments['test_corrections'])
        args = {**arguments, 'purpose': 'test'}
        return self.bash(args)

    def invoke(self, name, arguments):
        if name == 'read_round':
            data = json.dumps(self.state.read_round(arguments.get('attempt'), arguments.get('section', 'diagnosis')),
                              ensure_ascii=False, default=str)
            offset = arguments.get('offset', 0)
            if type(offset) is not int or offset < 0:
                raise ValueError('offset must be a nonnegative integer')
            end = min(len(data), offset + self.config.read_batch_chars)
            return {'content': data[offset:end], 'total_chars': len(data),
                    'next_offset': end if end < len(data) else None,
                    'note': 'Character-paginated ledger data; omitted content is not evidence.'}
        if name == "read_files":
            return self.read_files(arguments)
        if name == "bash":
            return self.bash(arguments)
        if name == 'run_tests':
            return self.run_tests(arguments)
        if name == "update_notes":
            premature = 'repair_review' in arguments and not (self.state.latest and self.state.latest.grade['tests_failed'])
            self.state.update_notes(arguments)
            return {"status": "Notebook updated", "notes": self.state.notes,
                    "note": 'Initial plan saved; premature repair_review ignored until failed grading.' if premature else '',
                    "source_paths": list(self.state.evidence)}
        raise ValueError(f"Unknown tool {name}; use bash, read_files, run_tests, update_notes or submit")

    def repository_map(self):
        result = self.sb.exec(python_command(MAP_SCRIPT), timeout_s=30)
        return result["output"][:16000] if result["exit_code"] == 0 else "Map unavailable: use targeted source reads."

    def issue_context(self):
        """Locate issue-named symbols before a model anchors on the first listed file."""
        text = json.dumps({key: self.state.task.get(key) for key in
                           ("problem_statement", "requirements", "interface")}, ensure_ascii=False)
        names = re.findall(r"\b([A-Za-z_]\w*)\s*\(", text)
        names += re.findall(r"\b[A-Z]\w*\.([a-z_]\w*)", text)
        common = {"dict", "str", "int", "list", "set", "tuple", "bool", "print", "self", "pattern", "text"}
        names = list(dict.fromkeys(n for n in names if len(n) > 2 and n not in common))[:8]
        locations, requests = [], []
        if names:
            command = ("git grep -n -I -F -w " + " ".join("-e " + shlex.quote(n) for n in names) +
                       " -- . ':!*.lock' ':!package-lock.json' | head -n 100")
            result = self.sb.exec(command, timeout_s=max(1, min(30, int(self.state.remaining_s))))
            for line in result.get("output", "")[:12000].splitlines():
                parts = line.split(":", 2)
                if len(parts) == 3 and parts[1].isdigit():
                    locations.append({"path": parts[0], "line": int(parts[1]), "text": parts[2][:200]})
            locations.sort(key=lambda hit: (
                any(part in ("test", "tests", "__tests__") for part in hit["path"].split("/")),
                not bool(re.search(r"\b(?:def|class|func|function)\s", hit["text"])), hit["path"], hit["line"]))
            for hit in locations:
                if len(requests) >= 4:
                    break
                if not any(r["path"] == hit["path"] and r["start_line"] <= hit["line"] <
                           r["start_line"] + r["num_lines"] for r in requests):
                    requests.append({"path": hit["path"], "start_line": max(1, hit["line"] - 10), "num_lines": 100})
        paths = re.findall(r"[\w./-]+\.(?:py|go|js|ts|tsx|java|rs|cpp|c|h|rb)\b", text)
        for path in dict.fromkeys(paths):
            if len(requests) >= 4:
                break
            if not any(r["path"] == path for r in requests):
                requests.append({"path": path, "start_line": 1, "num_lines": 100})
        return {"symbols": names, "locations": locations[:40], "source_requests": requests}
