"""Experiment settings. Course URLs, credentials and model IDs still come from env."""

from dataclasses import dataclass


@dataclass(frozen=True)
class AgentConfig:
    solver_model: str = "standard"
    orientation_model: str = "starter"
    reviewer_model: str = "expert"
    verification_mode: str = "local_tests"  # "reference" remains an explicit experiment.
    require_code_readiness: bool = True  # Executed smoke/build evidence before grading, in either mode.
    workers: int = 10
    api_concurrency: int = 3
    max_model_calls: int = 400  # All roles and physical retries, per task.
    max_output_tokens: int = 100000
    starter_output_tokens: int = 8192
    standard_output_tokens: int = 100000  # Emergency headroom, never a per-turn target.
    solver_turn_output_tokens: int = 16768  # Practical per-turn cap; model ceilings remain configurable.
    late_solver_output_tokens: int = 8192
    first_grade_target_s: int = 480  # Soft target for a complete verified first candidate.
    grading_reserve_s: int = 300  # Based on observed 246s evaluation; not a grader SLA.
    repair_reserve_s: int = 300
    expert_output_tokens: int = 32768
    max_bad_turns: int = 5  # Recovery reminder frequency, not a fatal read limit.
    orientation_calls: int = 0  # Deterministic navigation first; model orientation is optional.
    orientation_output_tokens: int = 2048
    review_enabled: bool = True
    stalled_failure_review_enabled: bool = True
    stalled_failure_review_turns: int = 10
    review_fallback_to_standard: bool = True  # Expert allowance unavailable, not an extra routine review.
    review_calls: int = 1  # Physical calls per review round, including retries.
    expert_review_calls: int = 2  # Optional evidence batch, then final advice; both are budgeted.
    review_format_retries: int = 1  # One tool-free format correction; all calls share budgets/caps.
    max_review_rounds: int = 15
    review_output_tokens: int = 4096
    standard_review_output_tokens: int = 32768
    expert_review_output_tokens: int = 32768
    review_context_chars: int = 32000
    review_repair_reserve_usd: float = 0.04
    review_min_remaining_s: int = 180
    require_repair_review: bool = True
    inspection_turn_limit: int = 25  # First no-edit checkpoint, not a fatal cutoff.
    stop_on_no_edit: bool = False  # Keep working until real time/call/dollar limits by default.
    solver_handoff_enabled: bool = False  # Starter-only solver experiment; no Standard handoff.
    solver_handoff_after_turns: int = 6
    stalled_solver_model: str = "standard"
    implementation_nudge_turns: int = 6  # Advisory only; new notes/reads cannot reset this.
    repair_action_turns: int = 3  # In-conversation reminder, never a reviewer trigger.
    inspection_recovery_turns: int = 25  # Full-tool solver turns per recovery window.
    max_inspection_recoveries: int = 2
    max_evaluations: int = 10
    reserve_restoration_grade: bool = True
    task_timeout_s: int = 1800
    api_timeout_s: int = 180
    run_budget_usd: float = 10.0
    task_budget_usd: float = 0.50
    expert_budget_usd: float = 0.40
    expert_calls: int = 9
    context_max_chars: int = 120000
    context_recent_exchanges: int = 6
    read_default_lines: int = 200
    read_max_lines: int = 500
    read_batch_chars: int = 24000
    command_output_chars: int = 12000
    log_dir: str = "madsOpt_logs"

    def __post_init__(self):
        for name in ("solver_model", "orientation_model", "reviewer_model", "stalled_solver_model"):
            if getattr(self, name) not in ("starter", "standard", "expert"):
                raise ValueError(f"{name} must be starter, standard, or expert")
        if self.verification_mode not in ("reference", "local_tests"):
            raise ValueError("verification_mode must be reference or local_tests")
        for name in ("workers", "api_concurrency", "max_model_calls", "max_output_tokens",
                     "starter_output_tokens", "standard_output_tokens", "expert_output_tokens",
                     "solver_turn_output_tokens", "late_solver_output_tokens", "first_grade_target_s",
                     "grading_reserve_s", "repair_reserve_s",
                     "standard_review_output_tokens", "expert_review_output_tokens",
                     "solver_handoff_after_turns", "stalled_failure_review_turns",
                     "max_bad_turns", "max_evaluations", "task_timeout_s", "api_timeout_s",
                     "review_output_tokens", "orientation_output_tokens",
                     "max_review_rounds", "implementation_nudge_turns", "repair_action_turns",
                     "inspection_turn_limit", "inspection_recovery_turns", "max_inspection_recoveries",
                     "context_recent_exchanges", "read_default_lines", "read_max_lines",
                     "read_batch_chars", "command_output_chars"):
            if type(getattr(self, name)) is not int or getattr(self, name) < 1:
                raise ValueError(f"{name} must be a positive integer")
        for name in ("stop_on_no_edit", "solver_handoff_enabled", "review_fallback_to_standard"):
            if type(getattr(self, name)) is not bool:
                raise ValueError(f"{name} must be boolean")
        if not 0 <= self.orientation_calls <= 3 or not 1 <= self.review_calls <= 2 or not 1 <= self.expert_review_calls <= 2:
            raise ValueError("Use 0–3 orientation calls and 1–2 calls per review round")
        if type(self.review_format_retries) is not int or self.review_format_retries not in (0, 1):
            raise ValueError("Use zero or one bounded review-format correction")
        if self.context_max_chars < 8000 or self.review_context_chars < 4000:
            raise ValueError("Context limits are too small for task instructions")

    @property
    def candidate_evaluations(self):
        # A restoration is a real evaluation. Keep its slot available.
        return max(1, self.max_evaluations - int(self.reserve_restoration_grade))

    def output_limit(self, tier):
        return min(self.max_output_tokens, getattr(self, f"{tier}_output_tokens"))

    def review_output_limit(self, tier):
        role_limit = getattr(self, f"{tier}_review_output_tokens", self.review_output_tokens)
        return min(self.output_limit(tier), role_limit)


CONFIG = AgentConfig()
