"""Per-task notebook and immutable graded candidates, outside the checkout."""

import hashlib
import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from .regressions import source_fingerprint


def digest(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def as_items(value):
    """Accept ordinary JSON and the JSON-in-a-string emitted by some models."""
    if isinstance(value, str):
        try:
            decoded = json.loads(value)
            if isinstance(decoded, (list, dict)):
                value = decoded
        except ValueError:
            pass
    return value if isinstance(value, list) else [value]


@dataclass
class Candidate:
    patch: str
    grade: dict
    notes: dict = field(default_factory=dict)

    @property
    def fingerprint(self):
        return digest(self.patch)


@dataclass
class TaskState:
    task: dict
    config: object
    started: float = field(default_factory=time.monotonic)
    calls: int = 0
    evaluations: int = 0
    evaluation_attempts: int = 0
    last_grade_solver_call: int = 0
    stalled_turns: int = 0
    review_rounds: int = 0
    reviewed_grade_count: int = 0
    review_history: list = field(default_factory=list)
    stall_reviewed_sources: set = field(default_factory=set)
    clarified_review_rounds: set = field(default_factory=set)
    continued: bool = False
    best: object = None
    latest: object = None
    patch_hash: str = ""
    last_local_test: object = None
    test_history: list = field(default_factory=list)
    failed_test_runs: dict = field(default_factory=dict)
    regression_blocker: object = None
    regression_required: dict = field(default_factory=dict)
    regression_current: dict = field(default_factory=dict)
    regression_error: str = ''
    test_corrections: list = field(default_factory=list)
    review_probe: object = None
    readiness_checks: list = field(default_factory=list)
    evidence: dict = field(default_factory=dict)
    notes: dict = field(default_factory=lambda: {
        "repo_map": "", "findings": [], "hypotheses": [], "ruled_out": [],
        "open_questions": [], "plan": [], "scenarios": [], "review": "",
        "requirements": [], "review_actions": [],
        "review_question": "",
    })
    grades: list = field(default_factory=list)
    round_history: list = field(default_factory=list)
    seen_patches: set = field(default_factory=set)
    samples: dict = field(default_factory=dict)
    last_graded_notes: dict = field(default_factory=dict)
    repair_review: object = None
    repair_history: list = field(default_factory=list)
    scenario_review_patch: object = None
    failure_checkpoint_due: bool = False
    no_edit_turns: int = 0
    inspection_recoveries: int = 0
    active_solver_model: str = ""
    issue_sources: list = field(default_factory=list)
    deadline_stage: str = ''
    source_hash: str = ''
    file_versions: dict = field(default_factory=dict)

    def __post_init__(self):
        self.directory = Path(self.config.log_dir) / str(self.key)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.patch_hash = digest("")
        self.source_hash = source_fingerprint('')
        self.active_solver_model = self.config.solver_model
        self.save()

    @property
    def key(self):
        return int(self.task["task"])

    @property
    def remaining_s(self):
        return max(0, self.config.task_timeout_s - (time.monotonic() - self.started))

    @property
    def review_used(self):
        return self.review_rounds > 0

    def log(self, event, **data):
        with (self.directory / "events.jsonl").open("a") as stream:
            stream.write(json.dumps({"event": event, "elapsed_s": round(time.monotonic() - self.started, 3),
                                     **data}, default=str, ensure_ascii=False) + "\n")

    def update_notes(self, changes):
        # Validate the complete update BEFORE mutation. A notebook embedded in one
        # findings string must not silently erase its actual plan and scenarios.
        allowed = set(self.notes) | {"repair_review", "next_step"}
        unknown = set(changes) - allowed
        if unknown:
            raise ValueError(f"Unknown notebook fields: {', '.join(sorted(unknown))}")
        normalized = dict(changes)
        lists = {"findings", "hypotheses", "ruled_out", "open_questions", "plan", "scenarios",
                 "requirements", "review_actions"}
        for name, value in changes.items():
            if name in lists:
                if isinstance(value, str):
                    try:
                        value = json.loads(value)
                    except ValueError as exc:
                        raise ValueError(f"{name} must be an array of text items; send plan/scenarios as separate fields") from exc
                if not isinstance(value, list) or len(value) > 24 or any(
                        not isinstance(item, str) or not item.strip() or len(item) > 1500 for item in value):
                    raise ValueError(f"{name} needs at most 24 nonempty text items, each under 1,500 characters")
                normalized[name] = value
            elif name in ("repo_map", "review", "review_question") and not isinstance(value, str):
                raise ValueError(f"{name} must be text")
        changes = normalized
        # Before grading there is no failed-cycle repair to describe. Preserve a
        # valid initial plan instead of throwing away the entire notebook update.
        premature = 'repair_review' in changes and not (self.latest and self.latest.grade['tests_failed'])
        repair = self.validate_repair_review(changes['repair_review']) if 'repair_review' in changes and not premature else None
        if premature:
            self.log('premature_repair_ignored', instruction='Initial plan saved; repair_review applies only after failed grading')
        step = changes.get("next_step")
        if "next_step" in changes:
            self.require_fields(step, ("action", "target", "reason", "change_or_question"), "next_step")
            if step["action"] not in ("implement", "inspect"):
                raise ValueError("next_step.action must be implement or inspect")
        for name, value in changes.items():
            if name not in self.notes or name == "next_step":
                continue
            if name in ("repo_map", "review", "review_question"):
                self.notes[name] = str(value)[:8000]
            elif name == "scenarios":
                # Retain prior coverage rather than silently replacing it on repair.
                self.notes[name] = list(dict.fromkeys(self.notes[name] +
                    value))[-24:]
            else:
                self.notes[name] = list(value)
        if repair is not None:
            self.repair_review = repair
            self.repair_history.append(repair)
            self.repair_history = self.repair_history[-12:]
            self.notes["plan"] = repair["planned_changes"]
            for case in repair["new_scenarios"]:
                scenario = json.dumps(case, ensure_ascii=False)
                if scenario not in self.notes["scenarios"]:
                    self.notes["scenarios"].append(scenario)
            self.notes["scenarios"] = self.notes["scenarios"][-24:]
            self.failure_checkpoint_due = False
            self.scenario_review_patch = None
            self.log("repair_review_recorded", review=repair)
        if step is not None:
            self.notes["next_step"] = {key: value[:1500] for key, value in step.items()
                                       if isinstance(value, str)}
        if isinstance(changes.get("review"), str) and changes["review"].strip():
            self.scenario_review_patch = self.patch_hash
        self.save()
        return self.notebook()

    @staticmethod
    def require_fields(value, names, label):
        if not isinstance(value, dict) or any(not isinstance(value.get(key), str) or
                                             not value[key].strip() for key in names):
            raise ValueError(f"{label} needs nonempty text fields: {', '.join(names)}")

    def validate_repair_review(self, value):
        if not self.latest or not self.latest.grade["tests_failed"]:
            raise ValueError("repair_review requires a previous failed grading result")
        if isinstance(value, str):
            try:
                value = json.loads(value)
            except ValueError as exc:
                raise ValueError("repair_review must be a JSON object, not an essay") from exc
        self.require_fields(value, ("previous_assumption", "missed_behavior"), "repair_review")
        cases, edits = value.get("new_scenarios"), value.get("planned_changes")
        if not isinstance(cases, list) or not 1 <= len(cases) <= 4:
            raise ValueError("repair_review.new_scenarios needs 1–4 concrete counterexamples")
        if not isinstance(edits, list) or not 1 <= len(edits) <= 6 or any(
                not isinstance(edit, str) or not edit.strip() for edit in edits):
            raise ValueError("repair_review.planned_changes needs 1–6 path/symbol-specific edits")
        known = {self.scenario_key(case) for review in self.repair_history
                 if review["for_patch_sha256"] != self.latest.fingerprint for case in review["new_scenarios"]}
        for case in cases:
            self.require_fields(case, ("previous_patch_behavior", "requirement"), "new_scenario")
            if "input" not in case or "expected" not in case:
                raise ValueError("new_scenario requires concrete input and expected fields; empty values/null are allowed")
            if len(json.dumps(case, ensure_ascii=False)) > 6000:
                raise ValueError("Keep each counterexample under 6,000 characters; use a smaller concrete input")
        if all(self.scenario_key(case) in known for case in cases):
            raise ValueError("These repair scenarios were already recorded; identify a genuinely new gap")
        return {"for_attempt": self.latest.grade["attempt"], "for_patch_sha256": self.latest.fingerprint,
                "previous_assumption": value["previous_assumption"][:1500],
                "missed_behavior": value["missed_behavior"][:1500],
                "new_scenarios": [json.loads(json.dumps({key: case[key] for key in
                    ("input", "expected", "previous_patch_behavior", "requirement")})) for case in cases],
                "planned_changes": [edit[:1500] for edit in edits]}

    @staticmethod
    def scenario_key(case):
        # Case, whitespace and value type can themselves be the missing behavior.
        return digest(json.dumps([case["input"], case["expected"]], sort_keys=True, ensure_ascii=False))

    @property
    def needs_repair_review(self):
        return bool(self.latest and self.latest.grade["tests_failed"] and
                    (not self.repair_review or self.repair_review["for_patch_sha256"] != self.latest.fingerprint))

    def track_edit_progress(self, previous_source_hash):
        if previous_source_hash != self.source_hash:
            self.no_edit_turns = self.inspection_recoveries = 0
        else:
            self.no_edit_turns += 1

    def record_read(self, path, file_hash, start, end, excerpt):
        previous = self.evidence.pop(path, {})  # Refresh insertion order for targeted reviewer retrieval.
        ranges = previous.get("ranges", []) if previous.get("sha256") == file_hash else []
        ranges = [r for r in ranges if r["start"] != start]
        ranges.append({"start": start, "end": end, "excerpt": excerpt[:5000]})
        self.evidence[path] = {"sha256": file_hash, "observed_at_patch": self.patch_hash,
                               "observed_version": self.file_versions.get(path, self.file_versions.get('*', '')),
                               "ranges": ranges[-4:]}
        while len(self.evidence) > 32:
            del self.evidence[next(iter(self.evidence))]

    def observe_patch(self, patch):
        fingerprint = digest(patch)
        changed = fingerprint != self.patch_hash
        if not changed:
            return False
        self.patch_hash = fingerprint
        self.source_hash = source_fingerprint(patch)
        self.file_versions = {}
        for chunk in re.split(r'(?m)(?=^diff --git )', patch):
            match = re.search(r'^diff --git a/.+? b/(.+)$', chunk, re.M)
            if match:
                self.file_versions[match[1]] = digest(chunk)
        if patch and not self.file_versions:
            self.file_versions['*'] = fingerprint
        if changed:
            self.last_local_test = None
            self.readiness_checks = []
            self.scenario_review_patch = None
        return changed

    def evidence_stale(self, path, info):
        if 'observed_version' not in info:
            return info['observed_at_patch'] != self.patch_hash
        return info['observed_version'] != self.file_versions.get(path, self.file_versions.get('*', ''))

    def notebook(self):
        return {"notes": self.notes, "source_evidence": {
            path: {**info, "needs_refresh": self.evidence_stale(path, info)}
            for path, info in self.evidence.items()}, "grades": self.grades,
            "current_patch_sha256": self.patch_hash,
            "best_patch_sha256": self.best.fingerprint if self.best else None,
            "verification_mode": self.config.verification_mode,
            "local_test": self.last_local_test, "test_history": self.test_history,
            "failed_test_runs": self.failed_test_runs,
            "validation_blocker": self.regression_blocker,
            "regression_inventory": {path: {'sha256': item['sha256'],
                'case_ids': list(item.get('cases', {}))} for path, item in self.regression_required.items()},
            "test_corrections": self.test_corrections, "review_probe": self.review_probe,
            "last_graded_notes": self.last_graded_notes,
            "readiness_checks": self.readiness_checks,
            "review_rounds": self.review_rounds, "review_history": self.review_history,
            "stall_reviewed_sources": sorted(self.stall_reviewed_sources),
            "clarified_review_rounds": sorted(self.clarified_review_rounds),
            "last_grade_solver_call": self.last_grade_solver_call,
            "active_solver_model": self.active_solver_model, "issue_sources": self.issue_sources,
            "deadline_stage": self.deadline_stage,
            "repair_review": self.repair_review, "repair_history": self.repair_history,
            "scenario_review_patch": self.scenario_review_patch,
            "no_edit_turns": self.no_edit_turns, "inspection_recoveries": self.inspection_recoveries,
            "round_history": self.round_history}

    def round_summary(self):
        """All rounds stay represented; full evidence is retrieved by attempt number."""
        return [{"attempt": r['grade']['attempt'], "tests_failed": r['grade']['tests_failed'],
                 "patch_sha256": r['patch_sha256'], "status": r['status'],
                 "issue_reasoned": {k: [text[:160] for text in v[:1]] for k, v in r['issue_reasoned'].items()},
                 "changed_paths": [p[:160] for p in r['changed_paths'][:3]],
                 "plan": [p[:160] for p in r['notes']['plan'][:1]],
                 "detail_tool": f"read_round(attempt={r['grade']['attempt']})"}
                for r in self.round_history]

    def read_round(self, attempt, section='diagnosis'):
        if type(attempt) is not int or attempt < 0:
            raise ValueError('attempt must be a nonnegative integer')
        record = next((r for r in self.round_history if r['grade']['attempt'] == attempt), None)
        if record is None:
            raise ValueError('No recorded grading with that attempt number')
        fields = {'diagnosis': ('issue_reasoned', 'repair_basis', 'notes', 'source_evidence'),
                  'checks': ('checks', 'local_test', 'test_history', 'regression_inventory', 'test_corrections'), 'review': ('reviewer_feedback',),
                  'patch': ('patch_file', 'changed_paths')}
        if section not in fields:
            raise ValueError('section must be diagnosis, checks, review or patch')
        result = {k: record.get(k) for k in fields[section]}
        if section == 'patch':
            result['patch'] = (self.directory / record['patch_file']).read_text()
        return {'attempt': attempt, 'grade': record['grade'], 'patch_sha256': record['patch_sha256'], **result}

    def save(self):
        target = self.directory / "working_state.json"
        temporary = target.with_suffix(".tmp")
        temporary.write_text(json.dumps(self.notebook(), indent=2, default=str, ensure_ascii=False))
        temporary.replace(target)
        # Full structural inventory is durable but stays OUT of model context.
        manifest = self.directory / 'regression_manifest.json'
        temporary_manifest = manifest.with_suffix('.tmp')
        temporary_manifest.write_text(json.dumps({'required': self.regression_required,
            'current': self.regression_current, 'error': self.regression_error,
            'corrections': self.test_corrections}, ensure_ascii=False))
        temporary_manifest.replace(manifest)

    def record_grade(self, patch, grade, restoration=False):
        self.evaluations += 1
        self.last_grade_solver_call = getattr(self, "role_calls", {}).get("solver", 0)
        notes = self.best.notes if restoration and self.best else self.notes
        self.latest = Candidate(patch, dict(grade), json.loads(json.dumps(notes)))
        snapshot = {"grade": dict(grade), "patch_sha256": digest(patch),
                    "notes": self.latest.notes, "repair_review": None if restoration else self.repair_review,
                    "restoration": restoration,
                    "verification_mode": self.config.verification_mode}
        (self.directory / f"candidate_{self.evaluations}.review.json").write_text(
            json.dumps(snapshot, indent=2, ensure_ascii=False))
        self.last_graded_notes = snapshot["notes"]
        self.repair_review = self.scenario_review_patch = None
        self.failure_checkpoint_due = bool(grade["tests_failed"] and self.config.require_repair_review)
        self.seen_patches.add(digest(patch))
        improved = self.best is None or grade["tests_failed"] < self.best.grade["tests_failed"]
        record = {"grade": dict(grade), "patch_sha256": digest(patch),
                  "patch_file": f'candidate_{self.evaluations}.patch',
                  "changed_paths": re.findall(r'^\+\+\+ b/(.+)$', patch, re.MULTILINE),
                  "issue_reasoned": {k: list(notes.get(k, [])) for k in
                                     ('findings', 'hypotheses', 'ruled_out', 'open_questions')},
                  "source_evidence": {path: {"sha256": info['sha256'],
                      "ranges": [{'start': r['start'], 'end': r['end']} for r in info['ranges']]}
                      for path, info in self.evidence.items()},
                  "notes": snapshot['notes'], "repair_basis": snapshot['repair_review'],
                  "checks": json.loads(json.dumps(self.readiness_checks)),
                  "local_test": self.last_local_test,
                  "test_history": json.loads(json.dumps(self.test_history)),
                  "regression_inventory": self.notebook()['regression_inventory'],
                  "test_corrections": json.loads(json.dumps(self.test_corrections)),
                  "status": 'resolved_by_grading' if not grade['tests_failed'] else 'unresolved',
                  "reviewer_feedback": [], "restoration": restoration}
        # A failing count does not disprove a particular diagnosis; model claims stay labeled.
        self.round_history.append(record)
        with (self.directory / 'grading_ledger.jsonl').open('a') as stream:
            stream.write(json.dumps(record, ensure_ascii=False, default=str) + '\n')
        if improved:
            self.best = self.latest
            (self.directory / "best.patch").write_text(patch)
        (self.directory / f"candidate_{self.evaluations}.patch").write_text(patch)
        self.grades.append({**grade, "patch_sha256": digest(patch), "improved": improved})
        self.log("grading", **self.grades[-1])
        self.save()
        return improved
