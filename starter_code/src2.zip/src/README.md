# Coding-agent workflow

The default is one Standard coding agent with executable regression tests. Expert is a read-only
reviewer **only after fresh failed grading**. These prompts adapt principles from the
[OpenAI coding guidance](https://developers.openai.com/cookbook/examples/gpt-5/codex_prompting_guide)
and [mini-SWE-agent workflow](https://github.com/SWE-agent/mini-swe-agent/blob/main/src/minisweagent/config/default.yaml).
They are not a universal best prompt or a guarantee of course-task success.

## Solve and repair

1. Inspect the issue-named entry points, callers and relevant helpers using the shallow repo map.
   Batch related reads. Preserve facts with source references; retrieve missing or stale ranges on demand.
2. Record a brief discrepancy and path/symbol-specific plan.
3. Write focused regression tests from the requirements, covering the main entry-point behavior,
   relevant boundaries and preserved contracts. Reproduce the buggy behavior before fixing when practical.
4. Implement the coherent source change, including affected callers. Inspect the cumulative diff.
5. Execute the regression and relevant existing tests. Fix failures and rerun. Do not treat imports,
   printed values, a prose prediction or a setup failure as passing behavioral tests.
6. Call `submit` explicitly when ready. There is no timer-driven grading while implementation is underway.
   The tool returns either completed grading or the precise validation error, not an early "grading
   requested" acknowledgement. An `evaluation_requested` event marks the actual dispatcher call.
   Only an explicit model `submit` starts grading a new candidate. Passing tests/builds, writing notes
   and time checkpoints never submit it. If blocked, fix the reported checks then call `submit` again;
   the earlier request is not queued for automatic retry. Prompts prioritize applying the concrete
   fix and testing issue entry points, then submitting immediately once intended work is complete.
7. On failed grading, request one review round for that grading result. Expert receives the issue,
   patch, inspected-source inventory/excerpts, plan, cases, actual test results and per-grading history.
8. Make Expert advice falsifiable: add its proposed counterexample and execute it with
   `run_tests(command=..., review_case=true)` **before** altering the reviewed implementation.
   An already-passing reproducer does not establish that defect; an import/setup error is inconclusive.
   For supported advice, refine the plan, add a regression for the newly identified gap,
   repair and rerun preserved and new cases before submitting again. Do not restart investigation.
   If Expert identifies missing evidence, resolve the exact named fact before making speculative edits.

A failed grade reveals counts, not hidden-test names or causes. Local tests are useful evidence,
not proof that all hidden tests pass. Test expectations must follow requirements rather than current
implementation or reviewer opinion. A deliberately corrected expectation needs an evidence-backed reason.

## Review boundaries

No pre-grading, no-patch, repeated-inspection or plan-not-implemented reviews exist.
Implementation reminders stay in the same solver conversation and do not purchase separate reviews.

An optional evidence call offers native `read_files` / `read_round`. If Expert already has a supported
finding it can finish immediately. Otherwise it may retrieve one targeted evidence batch.
The final report uses a **fresh request without any tool schemas or tool-choice parameter**.
This avoids carrying a tool-use conversation into an advice-only turn.

Accepted reports begin with `VERDICT` and `NEXT_ACTION`:

- `REPAIR / EDIT`: requirement, current source/observed evidence, concrete counterexample,
  minimal action and verification.
- `NEEDS_EVIDENCE / INSPECT`: exact path/symbol and unanswered question, why it matters and how
  the answer changes the repair. The compact repo map and inspected inventory guide this lookup.
- `NO_SUPPORTED_FINDING / NO_SUPPORTED_ACTION`: explicit unresolved uncertainty; not approval
  of a failed candidate.

The prompt asks for one or two findings, normally under 400 words, not an essay. The validator
checks the report contract; it cannot prove semantic correctness. Printed tool markup, incomplete
reports and output-truncated responses are rejected, never executed as commands. At most one
tool-free format correction is allowed, sharing all physical-call and dollar limits. An unavailable
review is recorded as unavailable, not successful advice. The same grade never triggers another round.

If Expert's call/dollar allowance cannot fit the review, `review_fallback_to_standard=True` makes one
bounded Standard review attempt using the same packet and any fresh evidence already retrieved.
`review_fallback` records the reason and the ledger names the actual model. Both tiers preserve the
solver repair reserve and obey the same task/run funds, deadline and physical-call limits. If those
shared resources cannot fit Standard either, record the review as unavailable and continue from
observed evidence. No routine pre-grading or timer-triggered reviews are added.

## Tools and verification

Solver tools are `read_files`, `bash`, `run_tests`, `update_notes` and `submit`. Bash handles coherent edits,
including multiple files. Reviewer tools are read-only. Printed tool-call text is not a native call.

Example regression execution (adapt paths and command to the repository):

```json
{
  "command": "python3 -B -m pytest tests/test_issue.py tests/test_nearby.py -q"
}
```

Use the `run_tests` tool for that example. It records the command, exit status, current patch and
regression inventory automatically and also supplies smoke execution evidence. Ordinary pytest,
unittest and common test/build/typecheck commands through `bash` are recognized even without `purpose`
and `covers`; custom test runners can always use `run_tests`. Simple `cd`, `timeout`/`gtimeout`, environment
prefixes and pipes are recognized; arbitrary multiline shell programs are not parsed. Known runners
override a mistaken inspection label. Explicit `covers` still narrows scope.
Automatic scope means **changed files**, not measured behavioral coverage: the model must actually
exercise the issue entry point. `go test`/`cargo test` also compile their selected packages/crates;
those runs supply both smoke and build evidence. JS tests alone do not establish TypeScript buildability.
Other build commands can still use an explicit `check_kind` when not recognized automatically.
Use real repository fixtures/setup. Orientation supplies package scripts, manager and project typecheck
settings. With a root tsconfig, direct `tsc file.ts` is rejected because it ignores those settings;
use the repository typecheck script or local tsc with `--project tsconfig.json --noEmit`.
Checks run under `errexit` and `pipefail`, so `check; echo EXIT:$?` cannot hide a failed check.
Obvious OR-masking, known empty/skipped reports (including GoCheck's skipped passing wrapper), and
Go no-test-files output without another tested package are rejected. This is not a complete shell
parser or proof that a custom command ran assertions. Syntax/global errors still block submission;
Git whitespace warnings alone are non-fatal and remain in the validation report.

Before grading, the harness checks:
- A nonempty, changed candidate not already graded.
- Compilation and newly introduced unresolved Python globals.
- Successful smoke execution for changed runtime files and builds for compiled sources/manifests.
- Successful regression execution on the exact current patch, with recorded scope for changed files.
- No silently removed/altered preserved regressions. After a failed grade with a saved test inventory,
  add a new case (or explicitly correct a requirement-inconsistent old oracle) before regrading.
- Reference mode still requires repair notes and a current-patch assessment. In local mode those notes
  remain useful context, but missing prose is not a substitute for—or extra gate beyond—executed checks.

Python test functions (including parametrization/decorators), fixtures and module setup are compared
structurally. Adding separate new cases/imports is allowed. Removing or altering a case requires explicit
review; changing fixtures may affect all cases and is flagged too. Other recognized test files use a
conservative ordered-line comparison, not a complete language parser. A deliberate oracle/fixture
correction can be sent to `run_tests` in `test_corrections`, with `path`, the exact `before_sha256` and
`after_sha256` from its warning, the authoritative `requirement` and a concrete `reason`. Corrections
are logged, not semantically certified. Deleted test files cannot be waived; restore/replace coverage.
This is an auditable guard against accidental loss, not a security boundary against malicious edits.
The inventory covers conventionally named changed/new test files (100 files, 2MB per file maximum);
custom-named reproducers should be placed in `tests/` or named `test_*` to be protected. Changes made
and undone inside one shell command are not separately observed. Exceeding a limit blocks submission
with an explicit error rather than silently claiming coverage was preserved.

Any patch edit invalidates previous test/readiness evidence. A later failed run overrides a prior pass.
Test records retain commands, exit status and bounded assertion output. New candidate grading requires
explicit model `submit`; finalization never grades an unsubmitted candidate when an allowance ends.
The existing restoration of an already submitted/graded best candidate remains unchanged, including
its counted regrade if needed to keep the final score consistent. Invalid/incomplete candidates do
not receive an uncounted automatic evaluation.

`verification_mode="reference"` remains an explicit experiment: traced cases rather than behavioral
test execution, but smoke/build checks are still required. Production defaults to `"local_tests"`.

## Configuration

Edit `config.py`; it is loaded when a new agent process starts. No live reload.

| Setting | Default | Meaning |
| --- | --- | --- |
| solver_model | standard | Coding model: starter / standard / expert |
| reviewer_model | expert | Reviewer after fresh failed grading; configurable for experiments |
| verification_mode | local_tests | Execute focused regression tests |
| workers / api_concurrency | 5 / 3 | Task workers / simultaneous model requests |
| max_model_calls / task_timeout_s | 400 / 1800 | Per-task physical calls / wall-clock allowance |
| max_evaluations | 10 | Includes the reserved best-candidate restoration grading |
| starter_output_tokens | 8192 | Per-call model ceiling |
| standard_output_tokens | 100000 | Headroom, not a spending target |
| solver_turn_output_tokens | 32768 | Practical per-solver-turn cap below the model ceiling |
| late_solver_output_tokens | 8192 | Smaller focused actions during the grading/repair planning window |
| first_grade_target_s | 480 | Soft target for a complete verified first candidate |
| grading_reserve_s / repair_reserve_s | 300 / 300 | Planning windows, proportional for short experiments |
| expert_output_tokens | 32768 | Per-call model ceiling |
| standard_review_output_tokens | 32768 | Reviewer-role ceiling when configured to Standard |
| expert_review_calls | 2 | Optional evidence batch plus final report |
| review_calls | 1 | Base round calls when using a cheaper reviewer |
| review_format_retries | 1 | Additional bounded correction of an invalid final report |
| review_context_chars | 32000 | Bounded initial review packet, with marked omissions |
| review_min_remaining_s | 180 | Reserve time for implementation after review |
| run_budget_usd / task_budget_usd | 10 / 0.50 | Shared run / per-task dollar limits |
| expert_budget_usd / expert_calls | 0.40 / 9 | Per-task Expert dollars / physical calls |

All model requests, including evidence reads, formatting corrections and transport retries, share the
budgets. Nine physical Expert calls do not mean nine guaranteed reviews: a two-call round uses two.
The gateway may lower an output ceiling to fit remaining dollars. A 100k ceiling and brevity instructions
do not guarantee low hidden-reasoning use. The practical solver-turn cap now bounds requests separately;
set it equal to the model ceiling to restore the previous behavior. Expert's per-call ceiling is unchanged.
No unsupported course-model reasoning controls are assumed.

Time checkpoints at the first-candidate target and late validation windows direct the solver to complete
the supported fix, verify and submit instead of continuing broad exploration. Requests are smaller and
their API timeout allowance is reduced near those windows. These are time-aware controls, not a hard
guarantee that a model finishes, an SDK request returns within a precise wall-clock time, or grading
finishes in 300 seconds. The full task allowance is not shortened and an unready patch is never graded
solely because a timer elapsed. Blocked submissions need another explicit `submit` after checks pass.

Use `workers=1` and runner `--limit 1` for an initial live check. Record configuration when comparing
with the previous version; this version adds practical per-turn caps, not new dollar budgets. Offline tests below
do not use API credentials, Docker or hidden tests.

Removed obsolete settings: early-review routing, stall-review timers/cooldowns, review-after-N-failures
thresholds and timer-based grading. Failed grading is the sole review trigger.

## Source layout and durable context

- `agentic_loop.py`: accounted model/tool loop, verification/submission, workers and best-patch finalization.
- `prompts.py`: concise solver workflow, verification modes, repair checkpoint and reviewer contract.
- `reviews.py`: fresh-failure scheduling, evidence packet, tool-free final report, bounded format correction.
- `task_state.py`: validated notes, evidence references, exact-patch checks and immutable grading history.
- `tools.py`: sandbox source reads, commands, notes and paginated round retrieval.
- `code_checks.py`: portable static compilation/name checks and readiness coverage.
- `regressions.py`: structural test snapshots, preservation checks and explicit oracle corrections.
- `cost_budget.py`: shared reservations, usage settlement and admission limits.
- `validation.py`: common wrapped command recognition, known empty/skipped report checks and project hints.
- `time_policy.py`: configurable per-turn limits and non-forcing deadline checkpoints.

Task-private logs are outside the task checkout:
`working_state.json`, `events.jsonl`, `grading_ledger.jsonl`, `candidate_N.patch`,
`candidate_N.review.json`, `best.patch`, raw review responses and accepted final reports,
`regression_manifest.json` and content-addressed `regression_snapshots/`. Snapshotting starts before
first grading, including initially failing tests. Full AST inventories stay on disk, not in each prompt.
Each grading snapshots the issue hypothesis, plan, cases, patch and executed checks. Expert can retrieve
a specific older round using `read_round` rather than receiving every old file and report each time.
Compaction pins the latest accepted report in full and retains bounded notes/source references.
Unknown notes fields, wrong list types and malformed whole-notebook strings return explicit errors
without partially mutating the existing plan. One phase-specific exception: a premature `repair_review`
is ignored with a warning, retaining the otherwise valid initial plan. It is not advertised before failure.

Reviewer context prioritizes complete Python issue entry points and known-file helpers where they fit,
plus test inventory/results, rather than arbitrary file headers. Bounded source truncation stays explicit;
Expert can request a targeted range. A counterexample probe records whether the implementation still
matches the reviewed source (test-only additions are ignored for this comparison). The model remains
responsible for faithfully encoding Expert's case and acting on the observed result; advice is not proof.

## Offline tests

From `starter_code`:

```bash
python3 -m unittest discover -s src/tests -v
```

Fixtures use temporary Git repositories, real local assertions, scripted model responses and fake
grading. They verify red/green regression execution, failed-grade Expert handoff, repair and regrading,
no pre-grading reviews, malformed report recovery, notes validation, budgeting, isolated workers,
static checks and best-patch recovery. This validates harness mechanics, not live model quality.
Adversarial cases reproduce test-suite shrinkage, changed assertions/skips, masked failures, unlabelled
test invocations, premature repair notes and an Expert counterexample that already passes.

The revised loop follows the evidence/validation separation described in
[OpenAI's iterative repair example](https://developers.openai.com/cookbook/examples/codex/build_iterative_repair_loops_with_codex):
execute validation and retain its feedback rather than assuming an edit or reviewer claim worked.
