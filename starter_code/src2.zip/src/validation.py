"""Recognize execution evidence without depending on model-supplied labels.

This is a conservative workflow classifier, not a shell security parser or a
behavioral coverage analyzer. Custom/multiline runners can use run_tests.
"""

import posixpath
import re
import shlex


def shell_commands(command):
    if '\n' in command or '<<' in command:
        return []
    try:
        lexer = shlex.shlex(command, posix=True, punctuation_chars=';&|')
        lexer.whitespace_split = True
        lexer.commenters = '#'
        segments, words = [], []
        for word in lexer:
            if word and set(word) <= set(';&|'):
                if words:
                    segments.append(words)
                words = []
            else:
                words.append(word)
        return segments + ([words] if words else [])
    except ValueError:
        return []


def unwrap(words):
    words = list(words)
    for _ in range(8):
        while words and re.match(r'^\w+=', words[0]):
            words.pop(0)
        if not words:
            break
        runner = posixpath.basename(words[0])
        if runner == 'env':
            words.pop(0)
            while words and words[0].startswith('-'):
                option = words.pop(0)
                if option in ('-u', '--unset') and words:
                    words.pop(0)
        elif runner in ('timeout', 'gtimeout'):
            words.pop(0)
            while words and words[0].startswith('-'):
                option = words.pop(0)
                if option in ('-s', '--signal', '-k', '--kill-after') and words:
                    words.pop(0)
            if not words or not re.fullmatch(r'\d+(?:\.\d+)?[smhd]?', words[0]):
                return []
            words.pop(0)
        elif runner in ('command', 'time'):
            words.pop(0)
            if words and words[0] == '-p':
                words.pop(0)
        else:
            break
    return words


def classify(command):
    info = {'test': False, 'build': False, 'tsc': False, 'source_arguments': []}
    for segment in shell_commands(command):
        words = unwrap(segment)
        if not words:
            continue
        runner, args = posixpath.basename(words[0]), words[1:]
        package_script = runner in ('npm', 'yarn', 'pnpm')
        if runner in ('npx', 'npm', 'yarn', 'pnpm'):
            if runner == 'npx':
                args = [a for a in args if not a.startswith('-')]
                runner, args = (args[0], args[1:]) if args else ('', [])
            elif args and args[0] in ('run', 'exec'):
                args = args[1:]
                runner, args = (args[0], args[1:]) if args else ('', [])
            elif args:
                runner, args = args[0], args[1:]
        python = bool(re.fullmatch(r'python(?:[23](?:\.\d+)?)?', runner))
        module = args[args.index('-m')+1] if python and '-m' in args and args.index('-m')+1 < len(args) else ''
        if (runner in ('pytest', 'py.test', 'jest', 'vitest', 'rspec')
                or (package_script and (runner == 'test' or runner.startswith('test:'))) or module in ('pytest', 'unittest')
                or (python and args and re.fullmatch(r'(?:.*/)?test_[\w.-]+\.py', args[0]))):
            info['test'] = True
        if runner in ('go', 'cargo') and args:
            info['test'] |= args[0] == 'test'
            # Both commands compile their selected packages/crates before tests.
            info['build'] |= args[0] in ('test', 'build', 'check')
        if runner in ('build', 'typecheck', 'type-check', 'check:types', 'tsc', 'vue-tsc'):
            info['build'] = True
        if runner in ('tsc', 'vue-tsc'):
            info['tsc'] = True
            info['source_arguments'] += [a for a in args if re.search(r'\.[cm]?[jt]sx?$', a)]
    return info


def masks_status(command):
    """Detect shell OR, not '||' inside a quoted JS/Python test expression."""
    # Heredoc source is program data, not shell operators; inspect its command
    # line only. This remains a workflow guard, not a full shell parser.
    head = command.splitlines()[0] if '<<' in command else command
    try:
        lexer = shlex.shlex(head, posix=False, punctuation_chars=';&|')
        lexer.whitespace_split = True
        return '||' in list(lexer) or bool(re.search(r';\s*(?:true|exit\s+0)\s*$', head))
    except ValueError:
        return False


def command_identity(command):
    """Keep test selection, ignore presentation flags when matching a rerun."""
    command = re.sub(r'\s+2>&1(?=\s|$)', '', command)
    for segment in shell_commands(command):
        if not classify(shlex.join(segment))['test']:
            continue
        words = unwrap(segment)
        if '-m' in words and words.index('-m') + 1 < len(words):
            words = words[words.index('-m') + 1:]
        environment = [w for w in segment if re.match(r'^\w+=', w)]
        presentation = {'-B', '-v', '-vv', '-vvv', '-q', '--verbose', '--quiet', '--no-header', '--no-summary'}
        return shlex.join(environment + [w for w in words if w not in presentation])
    return command.strip()


def behavioral_test_failure(result):
    output = result.get('output', '')
    return (result.get('exit_code') != 0 and not result.get('timed_out')
            and not re.search(r'UsageError|unrecognized arguments|ModuleNotFoundError|ImportError|command not found', output)
            and bool(re.search(r'\d+ failed|FAILED\s*\(|^FAIL:|^--- FAIL:|AssertionError', output, re.M)))


def test_failure_reason(result, command=''):
    """Reject known empty/skipped suites; do not treat an exit-0 wrapper as tests."""
    output = result.get('output', '')
    for segment in shell_commands(command):
        if classify(shlex.join(segment))['test'] and any(
                word in ('-h', '--help', '--version', '--collect-only', '--co', '--listTests', '--showConfig', '--no-run', '--list')
                or word == '-list' or word.startswith('-list=') for word in segment):
            return 'This command lists/collects tests or shows help; execute the regression tests instead'
    if re.search(r'\b\d+ tests? collected\b', output):
        return 'Tests were collected, not executed; run the regression tests'
    if re.search(r'Ran 0 tests|no tests ran|No tests found|collected 0 items', output, re.I):
        return 'No tests executed; choose the actual issue regression/test target'
    go_results = re.findall(r'^ok\s+[^\n]+', output, re.M)
    if re.search(r'\[no test files\]|no tests to run', output, re.I) and not any(
            '[no tests to run]' not in row for row in go_results):
        return 'No tests executed; choose the actual issue regression/test target'
    ran = re.search(r'Ran (\d+) tests?', output)
    skipped = re.search(r'OK \(skipped=(\d+)\)', output)
    counters = lambda label: [int(n) for n in re.findall(r'(\d+) (?:' + label + ')', output, re.I)]
    # GoCheck reports a passing Go wrapper even when its inner suite skips every
    # case. Do not confuse that wrapper with a real additional native Go test.
    current, skipped_wrappers = None, set()
    for line in output.splitlines():
        started = re.match(r'^=== RUN\s+(\S+)', line)
        if started:
            current = started[1]
        if re.search(r'OK:\s*0 passed,\s*\d+ skipped', line):
            skipped_wrappers.add(current)
    go_passes = set(re.findall(r'^--- PASS:\s+(\S+)', output, re.M))
    real_go_pass = bool(go_passes - skipped_wrappers)
    if ((ran and skipped and ran[1] == skipped[1])
            or (sum(counters('skipped')) > 0 and not sum(counters('passed'))
                and not sum(counters('failed|errors?')) and not real_go_pass)
            or ('--- SKIP:' in output and '--- PASS:' not in output and '--- FAIL:' not in output)):
        return 'All selected tests were skipped; execute the issue regressions'
    return ''


test_failure_reason.__test__ = False  # Suppress pytest collection: this is a utility, not a test.


def project_validation_info():
    # Self-contained: sent to the sandbox, never inspects course/hidden tests.
    import json
    from pathlib import Path
    root = Path('.').resolve()
    result = {'notes': ['Use repository setup and focused behavioral tests. Never install dependencies or use network.']}
    package = Path('package.json')
    if package.is_file() and package.resolve().parent == root and package.stat().st_size < 100000:
        try:
            data = json.loads(package.read_text())
            result['scripts'] = {k: str(v)[:500] for k, v in data.get('scripts', {}).items()
                                 if any(word in k.lower() for word in ('test', 'build', 'type', 'check'))}
            result['scripts'] = dict(list(result['scripts'].items())[:20])
        except (ValueError, OSError):
            result['package_error'] = 'Cannot parse package.json; inspect it before choosing commands'
        result['package_manager'] = 'yarn' if Path('yarn.lock').exists() else 'pnpm' if Path('pnpm-lock.yaml').exists() else 'npm'
    if Path('tsconfig.json').is_file():
        result['typescript'] = {'project': 'tsconfig.json',
            'focused_typecheck': './node_modules/.bin/tsc --project tsconfig.json --noEmit',
            'note': 'Prefer the repository typecheck script. Passing file names to tsc ignores project settings; do not do that.'}
    if Path('go.mod').is_file():
        result['go'] = 'Use go test ./affected/package/...; it also compiles that package. All-skipped suites are not behavioral proof.'
    if Path('Cargo.toml').is_file():
        result['rust'] = 'Use the affected crate tests; cargo test also compiles it.'
    return result
