"""Portable pre-grading checks, executed inside the task sandbox without dependencies."""

import inspect
import json
import shlex


def inspect_checkout():
    # Keep this function self-contained: its source is sent to the sandbox.
    import ast
    import builtins
    from pathlib import Path
    import subprocess
    import symtable
    import tokenize
    import warnings as compiler_warnings

    def undefined_globals(source, filename):
        tree = ast.parse(source, filename)
        if any(isinstance(node, ast.ImportFrom) and any(a.name == '*' for a in node.names)
               for node in ast.walk(tree)):
            return {}, True  # Wildcard imports cannot be resolved without importing code.
        root = symtable.symtable(source, filename, 'exec')
        known = set(dir(builtins)) | {'__file__', '__name__', '__package__', '__doc__',
            '__spec__', '__loader__', '__builtins__', '__cached__', '__path__'}

        def tables(table, scope=()):
            scope = scope + (table.get_name(),)
            yield table, scope
            for child in table.get_children():
                yield from tables(child, scope)

        scopes = list(tables(root))
        for table, _ in scopes:
            for symbol in table.get_symbols():
                if (table is root or symbol.is_global()) and (
                        symbol.is_assigned() or symbol.is_imported() or symbol.is_namespace()):
                    known.add(symbol.get_name())
        issues = {}
        for table, scope in scopes:
            for symbol in table.get_symbols():
                name = symbol.get_name()
                if symbol.is_referenced() and symbol.is_global() and name not in known:
                    issues[(scope, name)] = {'path': filename, 'scope': '.'.join(scope),
                        'line': table.get_lineno(), 'name': name, 'error': f"Undefined global: {name}"}
        return issues, False

    diff = subprocess.run(['git', 'diff', '--check', 'HEAD'], capture_output=True, text=True)
    paths = subprocess.check_output(['git', 'diff', '--name-only', '-z', 'HEAD']).decode().split('\0')
    paths = [p for p in paths if p]
    python_errors, undefined, warnings, checked = [], [], [], []
    for filename in paths:
        path = Path(filename)
        if path.suffix != '.py' or not path.is_file():
            continue
        try:
            with tokenize.open(filename) as stream:
                source = stream.read()
            # Keep compiler warnings in the JSON report, not mixed into stdout/stderr.
            with compiler_warnings.catch_warnings(record=True) as emitted:
                compiler_warnings.simplefilter('always')
                compile(source, filename, 'exec', dont_inherit=True)
                current, dynamic = undefined_globals(source, filename)
                baseline = subprocess.run(['git', 'show', f'HEAD:{filename}'], capture_output=True)
                old = {}
                if baseline.returncode == 0:
                    try:
                        old, _ = undefined_globals(baseline.stdout, filename)
                    except (SyntaxError, UnicodeError):
                        warnings.append(f'{filename}: baseline could not be analyzed')
            warnings.extend(dict.fromkeys(f'{filename}: {warning.message}' for warning in emitted))
            undefined.extend(value for key, value in current.items() if key not in old)
            if dynamic:
                warnings.append(f'{filename}: wildcard imports limit undefined-global analysis; smoke checks remain required')
            checked.append(filename)
        except (SyntaxError, UnicodeError, OSError, ValueError) as exc:
            python_errors.append(f'{filename}: {exc}')

    runtime_suffixes = {'.py', '.pyx', '.js', '.mjs', '.cjs', '.jsx', '.ts', '.tsx', '.vue',
        '.svelte', '.c', '.cc', '.cpp', '.cxx', '.h', '.hpp', '.rs', '.go', '.java', '.kt',
        '.cs', '.swift', '.rb', '.php', '.sh'}
    compiled_suffixes = {'.pyx', '.jsx', '.ts', '.tsx', '.vue', '.svelte', '.c', '.cc', '.cpp',
        '.cxx', '.h', '.hpp', '.rs', '.go', '.java', '.kt', '.cs', '.swift'}
    build_names = {'Makefile', 'CMakeLists.txt', 'Cargo.toml', 'go.mod', 'pom.xml',
        'build.gradle', 'build.gradle.kts', 'package.json', 'tsconfig.json', 'pyproject.toml', 'setup.py'}
    runtime_files = [p for p in paths if Path(p).suffix in runtime_suffixes or Path(p).name in build_names]
    build_files = [p for p in paths if Path(p).suffix in compiled_suffixes or Path(p).name in build_names]
    # Formatting warnings are useful feedback, not a reason to throw away a
    # runnable, behaviorally verified patch at its deadline. Git failures remain fatal.
    whitespace_only = diff.returncode == 2 and bool(diff.stdout) and not diff.stderr
    if whitespace_only:
        warnings.append('Non-fatal patch whitespace warnings: ' + diff.stdout[:2000])
    return {'ok': (diff.returncode == 0 or whitespace_only) and not python_errors and not undefined,
        'diff_check': diff.stdout + diff.stderr, 'python_errors': python_errors,
        'undefined_globals': undefined, 'checked_python': checked, 'warnings': warnings,
        'runtime_files': runtime_files, 'build_files': build_files}


def static_checks(sandbox, timeout_s=60):
    """Compile changed Python files and reject newly introduced unresolved globals."""
    script = inspect.getsource(inspect_checkout) + '\nimport json; print(json.dumps(inspect_checkout()))'
    response = sandbox.exec('python3 -c ' + shlex.quote(script), timeout_s=timeout_s)
    if response['exit_code'] or response.get('timed_out'):
        return {'ok': False, 'error': response.get('output', '')[-3000:]}
    try:
        return json.loads(response['output'])
    except (ValueError, KeyError):
        return {'ok': False, 'error': 'Invalid validation response', 'output': response.get('output', '')[-3000:]}


def readiness_gaps(state, checks):
    """Only actual successful commands on this exact patch can satisfy readiness."""
    latest = {}
    for check in state.readiness_checks:
        if check['patch_sha256'] == state.patch_hash:
            for path in check['covers']:
                latest[(check['kind'], path)] = check
    return {kind: [path for path in paths if not latest.get((kind, path), {}).get('passed')]
            for kind, paths in (('smoke', checks['runtime_files']), ('build', checks['build_files']))}


def local_test_gaps(state, paths):
    """Allow related test batches; a later failure for a path supersedes its pass."""
    latest = {}
    for record in state.test_history:
        if record['patch_sha256'] == state.patch_hash:
            for path in record.get('covers', []):
                latest[path] = record['passed']
    return sorted(path for path in paths if not latest.get(path))
