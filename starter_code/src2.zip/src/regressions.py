"""Durable regression inventory. Test claims are not proof of semantic coverage.

Python cases are compared structurally (including assertions/decorators). Other
test languages use conservative file comparison: any non-additive edit requires
an explicit requirement-backed correction. Snapshots live outside the checkout.
"""

import hashlib
import inspect
import json
import re
import shlex


def is_test_path(path):
    parts = path.replace('\\', '/').lower().split('/')
    name = parts[-1]
    return (any(p in ('test', 'tests', '__tests__', 'spec', 'specs') for p in parts[:-1])
            or name.startswith('test_') or name.endswith(('_test.py', '_test.go', '_spec.rb'))
            or bool(re.search(r'\.(?:test|spec)\.[cm]?[jt]sx?$', name)))


def describe_test(path, content):
    import ast
    import hashlib
    import re
    result = {'sha256': hashlib.sha256(content.encode()).hexdigest(), 'cases': {}, 'support': ''}
    if not path.endswith('.py'):
        # A conservative fallback, not a JS/Go parser. Removed/altered lines are
        # reviewable; an added test cannot silently replace a previous one.
        result['lines'] = [line.rstrip() for line in content.splitlines() if line.strip()]
        return result
    try:
        tree = ast.parse(content)
    except SyntaxError as exc:
        return {**result, 'error': str(exc)}

    def normalize(node):
        return ast.dump(node, include_attributes=False)

    def walk(body, prefix=''):
        support = []
        for node in body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith('test'):
                result['cases'][prefix + node.name] = normalize(node)
            elif isinstance(node, ast.ClassDef):
                # Keep fixture/class decorators and inheritance as support too.
                children = walk(node.body, prefix + node.name + '.')
                clone = ast.ClassDef(name=node.name, bases=node.bases, keywords=node.keywords,
                                     body=children, decorator_list=node.decorator_list)
                support.append(clone)
            else:
                support.append(node)
        return support

    result['support'] = [normalize(n) for n in walk(tree.body)]
    return result


def inventory_checkout(known_paths):
    # Self-contained when transported into the sandbox. Only the task checkout
    # and its public Git baseline are inspected, never grading infrastructure.
    import json
    import os
    import subprocess
    from pathlib import Path

    def git(*args):
        return subprocess.run(['git', *args], capture_output=True, check=False)

    changed = git('diff', '--name-only', '-z', 'HEAD')
    untracked = git('ls-files', '--others', '--exclude-standard', '-z')
    if changed.returncode or untracked.returncode:
        raise ValueError('Cannot inventory the checkout Git diff')
    paths = set(known_paths) | set((changed.stdout + untracked.stdout).decode().split('\0'))
    paths = sorted(p for p in paths if p and is_test_path(p))
    if len(paths) > 100:
        raise ValueError('More than 100 changed test files; narrow the task patch before grading')
    root = Path('.').resolve()
    records = {}
    for name in paths:
        path = Path(name)
        if os.path.commonpath([str(root), str(path.resolve())]) != str(root):
            raise ValueError('Test path escapes checkout: ' + name)
        baseline = git('show', 'HEAD:' + name)
        old = baseline.stdout.decode('utf-8', errors='replace') if baseline.returncode == 0 else None
        if path.is_file() and path.stat().st_size > 2_000_000:
            raise ValueError('Test file exceeds the 2MB inventory limit: ' + name)
        text = path.read_text(errors='replace') if path.is_file() else None
        records[name] = {'current': describe_test(name, text) if text is not None else None,
                         'baseline': describe_test(name, old) if old is not None else None,
                         'content': text, 'baseline_content': old}
    return records


def differences(before, after):
    if not after:
        return ['file deleted']
    if after.get('error'):
        return ['test source is not parseable: ' + after['error']]
    if not before or before['sha256'] == after['sha256']:
        return []
    if 'lines' in before:
        # Subsequence preserves repeated lines and order; sets would miss removal
        # of one identical assertion or damage to block structure.
        lines = iter(after.get('lines', []))
        if all(any(new == old for new in lines) for old in before['lines']):
            return []
        return ['non-additive test-file edit (language has no structural parser)']
    gaps = [case + ': removed or altered' for case, body in before['cases'].items()
            if after.get('cases', {}).get(case) != body]
    if any(item not in after.get('support', []) for item in before['support']):
        gaps.append('fixtures/imports/module setup changed; review their effect on preserved tests')
    return gaps


class RegressionGuard:
    def __init__(self, sandbox, state):
        self.sb, self.state = sandbox, state

    def capture(self):
        state = self.state
        script = ('import json,re,sys\n' + inspect.getsource(is_test_path) + '\n' +
                  inspect.getsource(describe_test) + '\n' + inspect.getsource(inventory_checkout) +
                  '\nprint(json.dumps(inventory_checkout(json.loads(sys.argv[1]))))')
        response = self.sb.exec('python3 -c ' + shlex.quote(script) + ' ' +
                                shlex.quote(json.dumps(list(state.regression_required))),
                                timeout_s=max(1, min(30, int(state.remaining_s))))
        if response.get('exit_code') or response.get('timed_out'):
            state.regression_error = response.get('output', '')[-1500:] or 'Test inventory failed'
            return self.summary()
        try:
            records = json.loads(response['output'])
        except (ValueError, KeyError):
            state.regression_error = 'Invalid test inventory response'
            return self.summary()
        state.regression_error = ''
        state.regression_current = {}
        snapshots = state.directory / 'regression_snapshots'
        snapshots.mkdir(exist_ok=True)
        for path, record in records.items():
            current, baseline = record['current'], record['baseline']
            required = state.regression_required.get(path)
            if required is None:
                required = baseline or current
                if required:
                    state.regression_required[path] = required
            state.regression_current[path] = current
            for kind, description in (('current', current), ('baseline', baseline)):
                if description:
                    target = snapshots / (description['sha256'] + '.txt')
                    if not target.exists():
                        target.write_text(record['content' if kind == 'current' else 'baseline_content'])
            # Additive edits become the next protected inventory immediately,
            # including before the first grading and before tests ever pass.
            if current and not differences(required, current):
                state.regression_required[path] = current
        return self.summary()

    def summary(self):
        state = self.state
        changes = []
        for path, before in state.regression_required.items():
            after = state.regression_current.get(path)
            reasons = differences(before, after)
            if reasons:
                changes.append({'path': path, 'before_sha256': before['sha256'],
                                'after_sha256': after['sha256'] if after else 'deleted',
                                'changes': reasons})
        return {'ok': not changes and not state.regression_error,
                'error': state.regression_error, 'changes_requiring_review': changes,
                'files': {path: {'sha256': info['sha256'], 'case_ids': list(info.get('cases', {}))}
                          for path, info in state.regression_current.items() if info},
                'note': 'Inventory protects case structure, not oracle correctness or exhaustive coverage.'}

    def accept_corrections(self, corrections):
        """Bind an explicit oracle/fixture correction to exact before/after files."""
        if not isinstance(corrections, list):
            raise ValueError('test_corrections must be an array')
        pending = {item['path']: item for item in self.summary()['changes_requiring_review']}
        accepted = []
        for correction in corrections:
            if not isinstance(correction, dict):
                raise ValueError('Each correction must be an object')
            path = correction.get('path')
            actual = pending.get(path)
            if not actual or any(correction.get(key) != actual[key] for key in ('before_sha256', 'after_sha256')):
                raise ValueError('Correction must match the current inventory warning and both hashes')
            if any(not isinstance(correction.get(key), str) or not correction[key].strip()
                   for key in ('requirement', 'reason')):
                raise ValueError('Correction needs the requirement and why the old test was wrong')
            if actual['after_sha256'] == 'deleted':
                raise ValueError('Restore or replace the regression; a deleted test file cannot be waived')
            accepted.append((path, correction))
        for path, correction in accepted:
            self.state.regression_required[path] = self.state.regression_current[path]
            self.state.test_corrections.append(dict(correction))
            self.state.log('test_oracle_correction', **correction)
        return self.summary()

    def added_cases_since_grade(self):
        if not self.state.round_history:
            return []
        before = self.state.round_history[-1].get('regression_inventory', {})
        added = []
        for path, current in self.state.regression_current.items():
            if not current:
                continue
            prior = before.get(path, {})
            added.extend(path + ':' + case for case in current.get('cases', {})
                         if case not in prior.get('case_ids', []))
            if 'lines' in current and current['sha256'] != prior.get('sha256'):
                added.append(path + ': changed non-Python regression (review scope manually)')
        return added


def source_fingerprint(patch):
    """Ignore test-only edits when checking a review's original counterexample."""
    chunks = re.split(r'(?m)(?=^diff --git )', patch)
    source = []
    for chunk in chunks:
        match = re.match(r'diff --git a/(.+?) b/([^\n]+)', chunk)
        if not match or not is_test_path(match.group(2)):
            source.append(chunk)
    return hashlib.sha256(''.join(source).encode()).hexdigest()
