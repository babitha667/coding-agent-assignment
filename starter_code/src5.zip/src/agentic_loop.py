"""Simple course agent: one conversation, ordinary tools, explicit grading.

The course entry point remains Agent(dispatcher).run(). Start reading at solve().
All repository access goes through Sandbox; only traces live in this process.
"""

import hashlib
import json
import os
import posixpath
import re
import shlex
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from dispatcher import DispatcherError, DispatcherShutdown
from .config import CONFIG
from .cost_budget import BudgetExceeded, CostBudget, RATES, field, input_sample, measured_input_bound, token_cost
from .sandbox import Sandbox


SYSTEM_PROMPT = """Task_description:
{problem_statement}

TASK_requirements:
{requirements}

Task_Interface:
{interface}

You are a software engineer with task requirements given to you.
You need to do what task DESCRIPTION/PROBLEM STATEMENT, REQUIREMENTS, INTERFACE are
asking for. Task specifications describe high-level business goals and requirements—they
are NOT an architectural blueprint, code structure, or schema definition. Do not invent
data schemas, function signatures, or code structures based on the wording of the
specification. The existing codebase is the sole authority on software design, data   
models, and architectural patterns. Always ground your implementation in the
repository, this does not mean you should simply inspect forever, implementation is
our GOAL: inspect existing callers, tests, and utility modules to understand
existing schemas, reuse existing helper functions, and fit your changes cleanly
into the codebase's existing architecture. DO NOT just go with what is already
implemented in the repo. There are hidden tests that needs to pass. You need to
implement a feature/solve a bug based on the description you got about the task.
Our GOAL is to quickly identify the issue/missing feature and implement!!! DO NOT over
re-read/re-inspect already read information because this info might be present in notes
that we are making and also we have a TIMER to finish the task. Read the task's problem,
requirements and interface - this will help in narrowing down the issue/feature. Search
the relevant symbols, inspect their implementations and callers, form a short
EVIDENCE-BACKED plan, then implement the complete fix promptly. Batch useful reads and
related edits. Use earlier tool results and NOTES instead of restarting investigation;
reread when necessary. Do not guess APIs or record shapes. Use the repository's
documented build process and configuration. Choose the narrowest valid build covering
all changed code. Allow SUFFICIENT TIME for COMPILATION. If it times out,
investigate the cause before retrying; do not repeatedly restart short builds
or hide failure exit codes.
search_files uses literal matching by default. Set regex=true when using regular
expressions such as foo|bar; without it, the entire pattern is searched literally.
An empty search result with the wrong mode is not evidence that symbols are absent.

Keep internal reasoning under 150 words. Do NOT generate combinatorial
proofs, exhaustive edge-case enumerations, or theoretical permutations. The
requested feature and its new behavior do NOT exist in the repository or its
test suite yet. Do not spend turns searching for existing tests or
implementations of the new functions. Once you locate the files to modify,
form a concise plan, make the edits promptly, and submit your first patch
within 15 turns of investigation. Consult the live
[Status: Turn N/max | Remaining time | Grading attempts] header to pace work.

Predict concrete normal, boundary, fallback, and regression scenarios directly
from the requirements. Mentally dry-run each scenario through the actual patched
code and its callers before calling submit:
- Verify each required success path and priority tier.
- Verify boundary cases.
- Verify negative/mismatch cases.
Keep each scenario trace concise (a 1-line input -> expected) rather than
writing lengthy combinatorial essays.

You may run EXISTING repository test suites (e.g. pytest, go test, cargo test)
via bash to verify your changes and catch regressions immediately. However, do
NOT create new test files or temporary scripts in the repository checkout, as
untracked files will pollute the submission git diff. Run the repository
build/typecheck or py_compile before calling submit alone. Inspect the diff
and call submit alone when the complete implementation is ready.

Grading returns counts, not hidden test identities. If tests fail, reconsider the
diagnosis, wrong tests predicted, missing cases and code contracts, update the
implementation, build and submit again. Continue from your existing work, not from
scratch. Never claim to know hidden tests. Do not access grader internals or the
network.

Commands run with Bash errexit and pipefail: failed commands and pipelines must
not be hidden behind echo or output filters. For expected nonzero statuses (such
as a search with no matches), handle the status explicitly. Use the repository's
build configuration. Give builds sufficient timeout rather than repeatedly killing
them. Write compiler output to a temporary regular file, never a /dev device.

Maintain concise incremental notes using the update_notes tool. Notes supplement
the conversation; they are not the only retained history.
Calling update_notes is REQUIRED whenever a turn produces useful new findings,
a concrete plan, edits, scenario traces, build results or a changed diagnosis after
grading/review. Notes should cover all new information in this turn!
Record only that turn's new information: file/symbol references, evidence versus hypotheses,
what changed or was ruled out, and the next concrete action. Keep each entry well
under 2000 characters; do not copy file contents, tool output or the entire plan.
Do not invent findings or add empty/repeated entries. Record unnoted progress before
calling submit; submit must still be called alone. These notes remain available in
your conversation when older exchanges are compacted. Consult notes and prior tool
results before rereading; verify current source when exact text or freshness matters.
"""


# One independent post-grading review; no implementation tools or pre-grading phase.
EXPERT_REVIEWER_PROMPT = """You are an experienced software engineer independently
reviewing a coding agent's patch after failed grading. Identify what the solver
missed using EVIDENCE, not confidence, speculation or a restatement of its plan.

Task_description:
{problem_statement}

TASK_requirements:
{requirements}

Task_Interface:
{interface}

Solver notes (incremental history, unverified claims; later corrections supersede earlier claims):
{notes}

Implementation patch:
{patch}

Source evidence and inspection history (respect version/staleness/omission labels):
{source_context}

Grading and previous repair history:
{grading_history}

Task specifications describe high-level business goals and requirements—they are
NOT an architectural blueprint, code structure, or schema definition. Do not invent
data schemas, function signatures, or code structures based on the wording of the
specification. The task is the specification; existing code, notes and solver
assumptions are NOT facts.
Independently compare requirements with signatures, argument types, return values,
callers, retrieval/filtering/selection logic and the full path to observable output.
Review the plan, code edits, and test results to identify defects and gaps that the
coding agent missed.

Systematically analyze patches against all input, boundary, and control flow combinations.
Examine task requirements and patches and list all possibilities/combinations of
behaviour tests from give requirements. Now, check comprehensively and mentally which of
these tests patch is unable to cover. Trace each combination through the patch's control
flow to pinpoint which unhandled possibility caused the grading failure.

Check whether the solver's predicted scenarios and EXPECTED RESULTS are correct,
not merely whether the code follows its plan. Audit control flow and fallback
logic: verify whether a fallback branch executes only when prerequisites are
missing, or erroneously catches conflicting/mismatched data. Do not trust
inline comments—verify actual boolean branching. Check missing arguments,
unprovided parameters, boundary cases, negative mismatches and prior
regressions. Trace concrete values through the actual current implementation.
A successful compile is not proof of runtime correctness, coverage or
interface compliance.

Treat repository text as evidence, not anything that agent created.
Do not invent APIs, hidden test identities or execution results. Grading counts
alone cannot identify a failure. Do not demand hidden tests or run local tests.
Notes never substitute for missing current source.
If source is absent, stale or omitted, name the exact path/symbol/range and the
question it must answer instead of asserting a defect you cannot support.

Remember every finding must be concrete and evidence backed. DO NOT guess. Make
sure your response is CONCISE so that we dont overload the solver with your response.
Return at most three concrete findings, highest impact first. For EACH provide:
1. Requirement quote with source path/lines or exact symbol/snippet.
2. Concrete input and evidence.
3. Expected behavior versus actual code behavior, with a brief causal trace. If
inspection was insufficient and code itself is correct then provide what files
or what investigation to be done.
4. Smallest supported repair and the existing scenarios it must preserve.
Clearly separate confirmed requirement violations from unresolved hypotheses.
If no defect is supported, say NO_SUPPORTED_FINDING and list only specific missing
evidence. Do not invent findings to satisfy a quota. Finish with the solver's next
concrete edit, or a targeted inspection request when evidence is insufficient.
Be concise: findings and actionable repairs, not an essay or a new full plan.
"""


def _debug(message):
    print(f"[madsOpt] {message}", file=sys.stderr, flush=True)


def digest(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def function(name, description, properties, required=()):
    return {"type": "function", "function": {"name": name, "description": description,
        "parameters": {"type": "object", "properties": properties, "required": list(required)}}}


TOOLS = [
    function("bash", "Search, inspect or edit the sandbox repository. Each command starts in "
             "the checkout. Prefer search_files/list_files for discovery to avoid shell quoting errors. "
             "Use build for build evidence; do not run tests. Example: {\"command\":\"git diff --stat\"}.", {
        "command": {"type": "string"}, "timeout_s": {"type": "integer"}}, ["command"]),
    function("list_files", "Discover repository-relative paths using a glob before reading them. "
             "Respects git ignore rules; no matches is success. Example: {\"pattern\":\"**/utils*.py\"}.", {
        "pattern": {"type": "string"}, "limit": {"type": "integer"}}, ["pattern"]),
    function("search_files", "Search repository text. Literal matching is the default: punctuation "
             "needs no regex or shell escaping. regex=true enables Python regex. No matches is success. "
             "Paths may be files or directories; omitted paths means the repository. Example: "
             "{\"pattern\":\".things(\",\"paths\":[\"openlibrary\"],\"regex\":false}.", {
        "pattern": {"type": "string"},
        "paths": {"type": "array", "items": {"type": "string"}},
        "regex": {"type": "boolean"}, "limit": {"type": "integer"}}, ["pattern"]),
    function("read_files", "Read multiple source ranges. Follow next_start_line when content "
             "is omitted. Reuse previous results when they answer your question. Example: "
             "{\"requests\":[{\"path\":\"src/main.py\",\"start_line\":1,\"num_lines\":100}]}.", {
        "requests": {"type": "array", "items": {"type": "object", "properties": {
            "path": {"type": "string"}, "start_line": {"type": "integer"},
            "num_lines": {"type": "integer"}}, "required": ["path"]}}}, ["requests"]),
    function("replace_text", "Apply exact, unique replacements in existing files. All edits "
             "are validated before writing. Each edit needs its own path; a top-level path is "
             "accepted as a shared fallback. Use bash for creating files. Example: "
             "{\"edits\":[{\"path\":\"src/main.py\",\"old_text\":\"x = 1\",\"new_text\":\"x = 2\"}]}.", {
        "edits": {"type": "array", "items": {"type": "object", "properties": {
            name: {"type": "string"} for name in ("path", "old_text", "new_text")},
            "required": ["path", "old_text", "new_text"]}}}, ["edits"]),
    function("update_notes", "Append a concise entry containing ONLY this turn's new findings, "
             "plan changes, edits, concrete scenario traces, build/grading results or unresolved "
             "questions. Include inspected paths/ranges where relevant. Required when useful new "
             "information exists; skip unchanged turns. Never rewrite the notebook or copy files. "
             "Explicitly correct superseded findings; do not claim unrun tests passed. "
             "Example: {\"notes\":\"Read src/main.py:10-30; caller passes a dictionary.\"}.", {
        "notes": {"type": "string"}}, ["notes"]),
    function("build", "Run the relevant build/typecheck/compile command, not tests. A successful "
             "build on the current patch is required before submit. "
             "Example: {\"command\":\"python3 -m py_compile src/main.py\"}.", {
        "command": {"type": "string"}, "timeout_s": {"type": "integer"}}, ["command"]),
    function("submit", "Call alone to grade the complete cumulative patch. Build first. "
             "Returns failing/total test counts for further repair. Example: {}.", {}),
]


SEARCH_SCRIPT = r'''
import fnmatch,json,re,subprocess,sys
from pathlib import Path
root=Path(sys.argv[1]).resolve(); args=json.loads(sys.argv[2])
mode=args['mode']; pattern=args['pattern']; limit=args['limit']; cap=args['cap']
try:
    rx=re.compile(pattern) if args.get('regex') else None
except re.error as exc:
    print(json.dumps({'error':'Invalid Python regex: '+str(exc),
                      'hint':'Use regex=false for literal punctuation.'})); sys.exit(0)
listed=subprocess.run(['git','ls-files','--cached','--others','--exclude-standard','-z'],
                      cwd=root,capture_output=True)
if listed.returncode:
    print(json.dumps({'error':'File discovery failed: '+listed.stderr.decode(errors='replace')})); sys.exit(0)
scopes=[]
for path in args.get('paths',['.']):
    resolved=(root/path).resolve()
    if not resolved.is_relative_to(root):
        print(json.dumps({'error':'Search path is outside checkout: '+path})); sys.exit(0)
    if not resolved.exists():
        print(json.dumps({'error':'Search path not found: '+path,'hint':'Use list_files to discover the path.'})); sys.exit(0)
    scopes.append(resolved)
items=[]; used=0; truncated=False; warnings=[]
for name in sorted(set(listed.stdout.decode(errors='replace').split('\0'))):
    if not name: continue
    path=(root/name).resolve()
    if not path.is_relative_to(root) or not path.is_file(): continue
    if not any(path==scope or path.is_relative_to(scope) for scope in scopes): continue
    if mode=='list_files':
        if not (fnmatch.fnmatchcase(name,pattern) or
                (pattern.startswith('**/') and fnmatch.fnmatchcase(name,pattern[3:]))): continue
        rows=[name]
    else:
        try:
            if path.stat().st_size>10000000:
                warnings.append(name+': skipped file over 10MB'); continue
            with path.open('rb') as stream:
                if b'\0' in stream.read(4096): continue
            def matching_rows():
                with path.open(encoding='utf-8',errors='replace') as stream:
                    for number,line in enumerate(stream,1):
                        if (rx.search(line) if rx else pattern in line):
                            value={'path':name,'line':number,'text':line.rstrip('\r\n')[:1000]}
                            if len(line.rstrip('\r\n'))>1000: value['line_truncated']=True
                            yield value
            rows=matching_rows()
        except OSError as exc:
            warnings.append(name+': '+str(exc)); continue
    try:
        for item in rows:
            size=len(json.dumps(item,ensure_ascii=False))+2
            if len(items)>=limit or used+size>cap:
                truncated=True; break
            items.append(item); used+=size
    except OSError as exc:
        warnings.append(name+': '+str(exc))
    if truncated: break
print(json.dumps({'files' if mode=='list_files' else 'matches':items,'truncated':truncated,
                  'warnings':warnings[:10]},ensure_ascii=False))
'''


def call_model(client, model_id, messages, logger, iteration, **kwargs):
    """Course API request; every completed response is recorded in the course trace."""
    response = client.chat.completions.create(model=model_id, messages=messages, **kwargs)
    usage = response.usage
    logger.api_request(iteration, field(usage, "prompt_tokens"), field(usage, "completion_tokens"),
                       field(usage, "total_tokens"), model_id)
    return response


class Agent:
    def __init__(self, dispatcher, config=None, client=None, sandbox_factory=Sandbox):
        self.dispatcher = dispatcher
        self.config = config or CONFIG
        cfg = self.config
        self.model_id = os.environ.get(f"CS2680_MODEL_{cfg.solver_model.upper()}", cfg.solver_model)
        if client is None:
            from openai import OpenAI
            client = OpenAI(base_url=os.environ["CS2680_BASE_URL"],
                            api_key=os.environ["CS2680_API_KEY"], max_retries=0)
        self.client = client
        self.sandbox_factory = sandbox_factory
        self.api_slots = threading.BoundedSemaphore(cfg.api_concurrency)
        # Solver and reviewer share the same per-task/run budgets and call allowance.
        self.budget = CostBudget(cfg.run_budget_usd, cfg.task_budget_usd,
                                 cfg.task_budget_usd, cfg.max_model_calls, cfg.max_model_calls)

    def run(self):
        """One worker owns each task until done; the dispatcher permits five live tasks."""
        with ThreadPoolExecutor(max_workers=self.config.workers) as pool:
            futures = [pool.submit(self.worker) for _ in range(self.config.workers)]
            for future in futures:
                future.result()

    def worker(self):
        while True:
            try:
                task = self.dispatcher.next_task()
            except DispatcherShutdown:
                return
            except DispatcherError as exc:
                if "live" not in str(exc).lower():
                    raise
                time.sleep(1)
                continue
            if task is None:
                return
            try:
                self.solve(task)
            except DispatcherShutdown:
                return

    def patch(self, key):
        """extract_patch returns a byte count, not the diff text."""
        self.dispatcher.extract_patch(key)
        return Path(self.dispatcher.patch_path(key)).read_text()

    def command(self, sb, arguments, remaining):
        command = arguments["command"]
        if not isinstance(command, str) or not command.strip():
            raise ValueError("command must be nonempty text")
        # Catch common accidental device deletion/output replacement. This is an
        # agent-side safety check, not a security boundary for arbitrary shell code.
        lexer = shlex.shlex(command, posix=True, punctuation_chars=';|&()<>')
        lexer.whitespace_split = True
        words = list(lexer)
        for index, word in enumerate(words):
            output = None
            if word in ('-o', '--output', '--output-file') and index + 1 < len(words):
                output = words[index + 1]
            elif word.startswith(('--output=', '--output-file=')):
                output = word.split('=', 1)[1]
            elif word.startswith('-o') and len(word) > 2:
                output = word[2:]
            if output and posixpath.normpath(output) == '/dev/null':
                raise ValueError("Do not use /dev/null as an output-file argument: tools may unlink it. "
                                 "Use a temporary regular file instead. Shell redirection to /dev/null is allowed.")
        if '/dev/null' in [posixpath.normpath(word) for word in words] and any(
                posixpath.basename(word) in ('rm', 'unlink', 'mv', 'install') for word in words):
            raise ValueError("Command may remove or replace /dev/null; preserve sandbox system devices")
        timeout = max(1, min(900, int(arguments.get("timeout_s", 60)), int(remaining)))
        result = sb.exec("bash -e -o pipefail -c " + shlex.quote(command), timeout_s=timeout)
        output = result.get("output", "")
        cap = self.config.tool_output_chars
        if len(output) > cap:
            result["output"] = output[:cap // 2] + "\n[OUTPUT OMITTED]\n" + output[-cap // 2:]
            result["output_truncated"] = True
        return result

    def read_files(self, sb, arguments):
        files, pending, room = [], [], self.config.tool_output_chars
        requests = arguments.get("requests", arguments.get("files"))
        if requests is None:
            for k, v in arguments.items():
                if "requests" in k or "files" in k:
                    if "[" in k and "]" in k:
                        m = re.search(r'\[.*\]', k, re.DOTALL)
                        if m:
                            try:
                                requests = json.loads(m.group(0))
                                break
                            except Exception:
                                pass
                    requests = v
                    break
            else:
                requests = [arguments]
        if isinstance(requests, str):
            try:
                decoded = json.loads(requests)
                if isinstance(decoded, (list, dict)):
                    requests = decoded
            except ValueError:
                pass
        if not isinstance(requests, list):
            requests = [requests] if requests else []
        if not requests:
            raise ValueError("requests must be a nonempty list")
        for index, request in enumerate(requests):
            if room < 200:
                pending = requests[index:]
                break
            if isinstance(request, str):
                request = {"path": request}
            if not isinstance(request, dict):
                files.append({"request": request, "error": "Each request must be an object with path; "
                              "example: {\"requests\":[{\"path\":\"src/main.py\"}]}"})
                continue
            path = request.get("path")
            if not isinstance(path, str) or not path.strip():
                files.append({"request": request, "error": "Missing nonempty path in read request; "
                              "example: {\"requests\":[{\"path\":\"src/main.py\"}]}"})
                continue
            try:
                lines = sb.read_text(path).splitlines()
                start = max(1, int(request.get("start_line", 1) or 1))
                count = min(self.config.read_max_lines,
                            max(1, int(request.get("num_lines", self.config.read_default_lines) or self.config.read_default_lines)))
                rows, next_line = [], None
                for number in range(start, min(len(lines) + 1, start + count)):
                    row = f"{number}: {lines[number - 1]}"
                    if len(row) + 1 > room:
                        next_line = number
                        break
                    rows.append(row)
                    room -= len(row) + 1
                end = start + len(rows) - 1
                if next_line is None and end < len(lines):
                    next_line = max(start, end + 1)
                files.append({"path": path, "content": "\n".join(rows), "total_lines": len(lines),
                              "next_start_line": next_line})
            except Exception as exc:
                files.append({"path": path, "error": f"{type(exc).__name__}: {exc}",
                              "hint": "Use list_files for missing paths; line offsets must be integers."})
        return {"files": files, "pending_requests": pending,
                "note": "For an oversized single line use targeted bash extraction."}

    @staticmethod
    def replace_text(sb, arguments):
        edits = arguments.get("edits")
        if edits is None:
            for k, v in arguments.items():
                if "edits" in k:
                    edits = v
                    break
            else:
                if all(k in arguments for k in ("path", "old_text", "new_text")):
                    edits = [arguments]
        if isinstance(edits, str):
            try:
                decoded = json.loads(edits)
                if isinstance(decoded, (list, dict)):
                    edits = decoded
            except ValueError:
                pass
        if not isinstance(edits, list):
            edits = [edits] if edits else []
        if not edits:
            raise ValueError("edits must be a nonempty list")
        pending = {}
        for index, edit in enumerate(edits):
            example = '{"edits":[{"path":"src/main.py","old_text":"x = 1","new_text":"x = 2"}]}'
            if not isinstance(edit, dict):
                raise ValueError(f"Edit {index + 1} must be an object. Example: {example}")
            path = edit.get("path", arguments.get("path"))
            if not isinstance(path, str) or not path.strip():
                raise ValueError(f"Edit {index + 1} needs path inside the edit or at top level. Example: {example}")
            if "old_text" not in edit or "new_text" not in edit:
                raise ValueError(f"Edit {index + 1} needs old_text and new_text. Example: {example}")
            old, new = edit["old_text"], edit["new_text"]
            if not all(isinstance(value, str) for value in (path, old, new)):
                raise ValueError("path, old_text and new_text must be strings")
            if not old or old == new:
                raise ValueError("old_text must be nonempty and different from new_text")
            text = pending[path] if path in pending else sb.read_text(path)
            if text.count(old) != 1:
                raise ValueError(f"old_text must match exactly once in {path}; read fresh source")
            pending[path] = text.replace(old, new, 1)
        for path, text in pending.items():
            sb.write_text(path, text)
        return {"edited_files": list(pending)}

    def search_repository(self, sb, name, arguments, remaining):
        """One shell-safe implementation for literal/regex search and glob discovery."""
        pattern = arguments.get('pattern')
        if not isinstance(pattern, str) or not pattern:
            raise ValueError('pattern must be nonempty text')
        paths = arguments.get('paths', ['.'])
        if isinstance(paths, str):
            paths = [paths]
        if not isinstance(paths, list) or not paths or any(not isinstance(p, str) or not p for p in paths):
            raise ValueError('paths must be a nonempty list of file/directory names')
        regex = arguments.get('regex', False)
        if type(regex) is not bool:
            raise ValueError('regex must be true or false; use false for literal matching')
        args = {'mode': name, 'pattern': pattern, 'paths': paths, 'regex': regex,
                'limit': max(1, min(500, int(arguments.get('limit', 100)))),
                'cap': self.config.tool_output_chars}
        command = 'python3 -c ' + shlex.quote(SEARCH_SCRIPT) + ' ' + shlex.quote(sb.workdir) + ' ' + shlex.quote(json.dumps(args))
        result = sb.exec(command, timeout_s=max(1, min(60, int(remaining))))
        if result.get('exit_code') or result.get('timed_out'):
            return {'error': result.get('output') or 'Search failed or timed out'}
        return json.loads(result['output'])

    def append_note(self, directory, text, call):
        """Persist one turn entry without overwriting earlier entries."""
        if not isinstance(text, str) or not text.strip():
            raise ValueError("notes must be nonempty text")
        if len(text) > self.config.notes_entry_max_chars:
            raise ValueError(f"Send only this turn's new information, under {self.config.notes_entry_max_chars} characters")
        entry = f"[Turn {call}]\n{text.strip()}\n\n"
        with (directory / "notes.txt").open("a") as stream:
            stream.write(entry)
        return entry

    def review_context(self, sb, patch, paths, observations, limit):
        """Current inspected/changed files, then historical tool evidence, with explicit omissions."""
        changed = re.findall(r"^\+\+\+ b/(.+)$", patch, re.MULTILINE)
        paths = list(dict.fromkeys(changed + sorted(paths)))
        context = {"source_paths": paths, "current_files": [], "historical_tools": [],
                   "omitted_files": [], "omitted_tool_calls": [],
                   "warning": "Historical outputs may be stale; current files and patch take precedence."}
        # Leave space for the omission inventory; never silently cut a source block.
        inventory_size = len(json.dumps(paths)) + len(str([item['call'] for item in observations]))
        room = max(0, limit - inventory_size - 1000)
        for path in paths:
            try:
                text = sb.read_text(path)
                item = {"path": path, "sha256": digest(text), "content": text}
            except Exception as exc:
                item = {"path": path, "error": str(exc)}
            size = len(json.dumps(item, ensure_ascii=False))
            if size <= room:
                context['current_files'].append(item)
                room -= size
            else:
                context['omitted_files'].append(path)
        for item in reversed(observations):
            size = len(json.dumps(item, ensure_ascii=False))
            if size <= room:
                context['historical_tools'].append(item)
                room -= size
            else:
                context['omitted_tool_calls'].append(item['call'])
        context['historical_tools'].reverse()
        return json.dumps(context, ensure_ascii=False)

    def compact(self, messages, notes, grades):
        """Keep full solver evidence until the context limit requires compaction."""
        if len(json.dumps(messages)) <= self.config.context_max_chars:
            return messages
        limit = self.config.context_max_chars
        starts = [i for i, msg in enumerate(messages) if i >= 2 and msg["role"] == "assistant"]
        keep = starts[-self.config.context_recent_exchanges:] or [len(messages)]
        # Keep complete recent entries in context; the full journal stays on disk.
        recent, used = [], 0
        for entry in reversed(notes):
            if used + len(entry) > self.config.notes_max_chars:
                break
            recent.append(entry)
            used += len(entry)
        note_text = "".join(reversed(recent))
        if len(recent) < len(notes):
            note_text = "[Older note entries omitted here; full journal retained in notes.txt.]\n" + note_text
        if not notes:
            note_text = "[No notes recorded yet. Record useful new findings with update_notes.]"
        roots = messages[:2] + [{"role": "user", "content":
            "Older exchanges were omitted, not undone. Continue the SAME task. "
            "Read source again if exact text is missing. Recent incremental notes:\n" + note_text +
            "\nGrading history:\n" + json.dumps(grades)}]
        tail = messages[keep[0]:]
        while tail and len(json.dumps(roots + tail)) > limit:
            end = next((i for i in range(1, len(tail)) if tail[i]["role"] == "assistant"), len(tail))
            tail = tail[end:]
        return roots + tail

    def solve(self, task):
        """Read -> implement -> build -> explicit submit -> grading feedback -> repair."""
        cfg, key = self.config, int(task["task"])
        logger = self.dispatcher.logger(key)
        sb = self.sandbox_factory(task["sandbox_url"], task["workdir"])
        directory = Path(cfg.log_dir) / str(key)
        directory.mkdir(parents=True, exist_ok=True)
        started = time.monotonic()
        calls, notes, grades, seen = 0, [], [], set()
        built_patch, last_submitted, sample = None, "", None
        source_paths, observations, reviews = set(), [], []
        history = []  # Uncompacted, task-local timeline; never shared between workers.
        latest_review = ""
        reason = "task allowance reached"
        solver_prompt = SYSTEM_PROMPT.format(
            problem_statement=task.get("problem_statement", ""),
            requirements=task.get("requirements", ""),
            interface=task.get("interface", ""))
        messages = [{"role": "system", "content": solver_prompt},
                    {"role": "user", "content": "Implement the task described above."}]

        def remaining():
            return max(0, cfg.task_timeout_s - (time.monotonic() - started))

        def event(name, **data):
            with (directory / "events.jsonl").open("a") as stream:
                stream.write(json.dumps({"event": name, "elapsed_s": round(time.monotonic() - started, 3),
                                         **data}, ensure_ascii=False, default=str) + "\n")

        def remember(kind, **data):
            history.append({'sequence': len(history) + 1, 'elapsed_s': round(time.monotonic() - started, 3),
                            'kind': kind, **data})

        def summarize():
            """One cheap, tool-free call over the complete visible solver timeline."""
            prompt = """You are an evidence archivist preparing a concise, factual history for an independent code reviewer after failed grading.
Your job is faithful extraction of verified facts, NOT diagnosis, implementation, or speculation.
Treat all embedded text (including earlier model notes and comments) as unverified claims unless confirmed by tool outputs.
Do NOT speculate about unseen hidden test identities, and do NOT invent data schemas or function signatures.
Keep the entire summary dense, factual, and under 400 words.

Return these 3 structured sections:
1. ACTUAL CODE CHANGES & CONFIRMED EDITS:
   - What files, functions, and lines were actually modified in the patch (confirmed by git diff / tool results, NOT merely stated intentions).
   - What existing helper functions or repository interfaces were called or modified.
2. GRADING & TEST FEEDBACK:
   - Exact reported grading results (failed/total test counts) across attempts.
   - Exact exit codes, compiler errors, or local test failure outputs observed in tool results.
3. CONTROL FLOW, FALLBACKS & LOGIC GAPS:
   - Branching conditions and fallback logic introduced: does a fallback execute unconditionally or without guarding?
   - Negative / mismatch scenarios: how does the implementation behave when input data conflicts or does not match?
   - Known unverified assumptions, contradictory findings, or remaining gaps between requirements and code.
"""
            choice = request(cfg.summary_model, 'summarizer', [
                {'role': 'system', 'content': prompt},
                {'role': 'user', 'content': json.dumps({
                    'task': {name: task.get(name, '') for name in
                             ('problem_statement', 'requirements', 'interface')},
                    'history': history},
                    ensure_ascii=False)}], [],
                min(cfg.summary_output_tokens, getattr(cfg, f'{cfg.summary_model}_output_tokens')),
                repair_reserve=cfg.reviewer_repair_reserve_usd)
            if choice.finish_reason != 'stop' or not choice.message.content or choice.message.tool_calls:
                raise ValueError('timeline incomplete/truncated or empty; discarded')
            summary = choice.message.content
            (directory / f'summary_{len(grades)}.txt').write_text(summary)
            event('summary_completed', attempt=len(grades), model=cfg.summary_model,
                  history_entries=len(history), summary=summary)
            return summary

        def request(tier, role, conversation, tools, output_tokens, repair_reserve=0):
            """Retry only transport failures and transient HTTP statuses, never tool execution."""
            from openai import APIConnectionError, APIStatusError

            for attempt in range(cfg.api_max_retries + 1):
                try:
                    return request_once(tier, role, conversation, tools, output_tokens, repair_reserve)
                except (APIConnectionError, APIStatusError) as exc:
                    status = getattr(exc, 'status_code', None)
                    transient = isinstance(exc, APIConnectionError) or status in (408, 409, 429) or (
                        status is not None and status >= 500)
                    if not transient or attempt >= cfg.api_max_retries:
                        raise
                    delay = min(2 ** attempt, 8)
                    response = getattr(exc, 'response', None)
                    retry_after = response.headers.get('retry-after') if response is not None else None
                    try:
                        delay = max(delay, float(retry_after)) if retry_after else delay
                    except (ValueError, TypeError):
                        pass
                    reserve_s = 60 if role in ('reviewer', 'summarizer') else 0
                    if remaining() <= delay + reserve_s + 1 or calls >= cfg.max_model_calls:
                        raise
                    event('api_retry', role=role, tier=tier, retry=attempt + 1,
                          delay_s=delay, status=status, error=str(exc))
                    time.sleep(delay)  # request_once released the shared API slot already.

        def request_once(tier, role, conversation, tools, output_tokens, repair_reserve=0):
            """One budgeted/logged API gateway for solver, summarizer and reviewer."""
            nonlocal calls, sample
            if calls >= cfg.max_model_calls or remaining() <= 0:
                raise BudgetExceeded("task time/model-call allowance reached")
            if not self.api_slots.acquire(timeout=max(0.01, remaining())):
                raise BudgetExceeded("deadline waiting for API slot")
            try:
                if remaining() <= (60 if role in ('reviewer', 'summarizer') else 0):
                    raise BudgetExceeded("insufficient time for this call and subsequent repair")
                model = os.environ.get(f"CS2680_MODEL_{tier.upper()}", tier)
                options = {"model": model}
                if tools:
                    options.update(tools=tools, tool_choice="auto")
                bound = self.budget.estimate_input(key, conversation, options, sample if role == 'solver' else None)
                if repair_reserve:
                    budget = self.budget.snapshot(key)
                    available = min(budget['task_remaining_usd'], budget['run_remaining_usd']) - repair_reserve
                    affordable = int((available - token_cost(tier, bound, 0)) * 1_000_000 / RATES[tier][2])
                    output_tokens = min(output_tokens, affordable)
                    if output_tokens < 512:
                        raise BudgetExceeded(f"insufficient review budget: estimated input={bound} tokens "
                            f"(${token_cost(tier, bound, 0):.4f}), available after repair reserve=${available:.4f}")
                ticket = self.budget.reserve(key, tier, role, conversation, options,
                    output_tokens, input_bound=bound, repair_reserve=repair_reserve)
                calls += 1
                event("model_input", call=calls, role=role, tier=tier, messages=conversation,
                      output_limit=ticket.output_limit)
                _debug(f"task {key}: {role}/{tier}, call={calls}")
                try:
                    response = call_model(self.client, model, conversation, logger, calls,
                        max_tokens=ticket.output_limit,
                        timeout=min(cfg.api_timeout_s, max(1, remaining() - (60 if role in ('reviewer', 'summarizer') else 0))),
                        **{name: value for name, value in options.items() if name != 'model'})
                except Exception:
                    event("api_error", role=role, tier=tier, accounting=self.budget.settle(ticket))
                    raise
                accounting = self.budget.settle(ticket, response.usage)
                if role == 'solver':
                    sample = input_sample(conversation, options, response.usage)
                event("api_response", call=calls, role=role, tier=tier,
                      finish_reason=response.choices[0].finish_reason,
                      response=response.model_dump(), accounting=accounting)
                return response.choices[0]
            finally:
                self.api_slots.release()

        def review(patch):
            """One history summary then one review per failed grading; repair can continue on failure."""
            if not cfg.reviewer_enabled:
                return ""
            try:
                if remaining() < cfg.reviewer_min_remaining_s or calls + 2 >= cfg.max_model_calls:
                    raise BudgetExceeded("insufficient remaining time/calls for review and repair")
                try:
                    timeline = summarize()
                except DispatcherShutdown:
                    raise
                except Exception as exc:
                    timeline = '[Timeline unavailable; no summary claims should be assumed.]'
                    event('summary_skipped', attempt=len(grades), reason=f'{type(exc).__name__}: {exc}')
                fields = dict(
                    problem_statement=task.get('problem_statement', ''),
                    requirements=task.get('requirements', ''), interface=task.get('interface', ''),
                    notes=(''.join(notes) or '[No solver notes recorded; inspect source independently.]') +
                          '\nChronological history summary (verify claims against current source/patch):\n' + timeline,
                    patch=patch, source_context='',
                    grading_history=json.dumps({'grades': grades, 'prior_reviews': reviews}))
                room = cfg.reviewer_context_chars - len(EXPERT_REVIEWER_PROMPT.format(**fields))
                if room < 2000:
                    raise BudgetExceeded("task/patch/notes leave insufficient review context; nothing silently truncated")
                fields['source_context'] = self.review_context(sb, patch, source_paths, observations, room)
                prompt = EXPERT_REVIEWER_PROMPT.format(**fields)
                if len(prompt) > cfg.reviewer_context_chars:
                    raise BudgetExceeded("review context exceeds configured limit")
                choice = request(cfg.reviewer_model, 'reviewer',
                    [{"role": "system", "content": prompt},
                     {"role": "user", "content": "Review this failed candidate; return evidence-backed findings."}], [],
                    min(cfg.reviewer_output_tokens, getattr(cfg, f'{cfg.reviewer_model}_output_tokens')),
                    repair_reserve=cfg.reviewer_repair_reserve_usd)
                if choice.finish_reason != 'stop' or not choice.message.content or choice.message.tool_calls:
                    raise ValueError("review incomplete/truncated or empty; partial advice discarded")
                advice = choice.message.content
                reviews.append({'grading_attempt': grade['attempt'], 'advice': advice})
                remember('expert_review', call=calls, attempt=len(grades), advice=advice)
                (directory / f'review_{len(grades)}.txt').write_text(advice)
                event('review_completed', attempt=len(grades), model=cfg.reviewer_model, advice=advice)
                return advice
            except DispatcherShutdown:
                raise
            except Exception as exc:
                event('review_skipped', attempt=len(grades), reason=f'{type(exc).__name__}: {exc}')
                return f"Review unavailable ({type(exc).__name__}: {exc}). Continue evidence-based repair yourself."

        try:
            while remaining() > 0 and calls < cfg.max_model_calls:
                turn_status = f"\n\n[Status: Turn {calls + 1}/{cfg.max_model_calls} | Remaining time: {int(remaining())}s | Grading attempts: {len(grades)}/{cfg.max_evaluations}]"
                messages[0] = {"role": "system", "content": solver_prompt + turn_status}
                messages = self.compact(messages, notes, grades)
                if latest_review and not any(latest_review in msg.get('content', '') for msg in messages):
                    messages.append({"role": "user", "content": "Latest independent review (verify claims):\n" + latest_review})
                choice = request(cfg.solver_model, 'solver', messages, TOOLS, cfg.output_tokens)
                remember('solver_response', call=calls, finish_reason=choice.finish_reason,
                         response=choice.message.model_dump(include={'role', 'content', 'tool_calls'}, exclude_none=True))
                if choice.finish_reason == "length":
                    messages.append({"role": "user", "content":
                        "Your last response was truncated; no partial tools were executed. "
                        "Continue with a smaller, complete tool action. Do not restart the task."})
                    continue
                message = choice.message.model_dump(include={"role", "content", "tool_calls"},
                                                    exclude_none=True)
                messages.append(message)
                tool_calls = message.get("tool_calls", [])
                if not tool_calls:
                    messages.append({"role": "user", "content":
                        "Continue using tools to complete the fix. When ready, build and call submit."})
                passed = False
                for call in tool_calls:
                    name = call["function"]["name"]
                    tool_iteration, args = calls, {}
                    try:
                        args = json.loads(call["function"]["arguments"])
                        if not isinstance(args, dict):
                            raise ValueError("Tool arguments must be an object")
                        logger.tool_call(calls, name, args)
                        if name == "read_files":
                            result = self.read_files(sb, args)
                            source_paths.update(posixpath.relpath(item['path'], sb.workdir)
                                if item['path'].startswith('/') else posixpath.normpath(item['path'])
                                for item in result.get('files', []) if not item.get('error'))
                        elif name in ('list_files', 'search_files'):
                            result = self.search_repository(sb, name, args, remaining())
                        elif name == "replace_text":
                            result = self.replace_text(sb, args)
                        elif name in ("bash", "build"):
                            result = self.command(sb, args, remaining())
                            if name == "build":
                                # A failed build clears earlier success, even on identical source.
                                built_patch = None
                                if result.get("exit_code") == 0 and not result.get("timed_out"):
                                    built_patch = digest(self.patch(key))
                        elif name == "update_notes":
                            notes.append(self.append_note(directory, args["notes"], calls))
                            result = {"appended": True, "entry_count": len(notes)}
                        elif name == "submit":
                            if len(tool_calls) != 1:
                                raise ValueError("Call submit alone, after edits and build finish")
                            patch = self.patch(key)
                            if not patch.strip():
                                raise ValueError("No patch to grade; implement the fix first")
                            if digest(patch) in seen:
                                raise ValueError("This exact patch was graded already; revise it using the feedback")
                            if digest(patch) != built_patch:
                                raise ValueError("Run build on the CURRENT patch before submitting")
                            if len(grades) >= cfg.max_evaluations:
                                raise BudgetExceeded("grading allowance reached")
                            if grades:
                                self.dispatcher.continue_task(key)
                            self.dispatcher.submit_patch(key, patch)
                            event("evaluation_requested", call=calls, patch_sha256=digest(patch))
                            grade = self.dispatcher.evaluate(key)
                            last_submitted = patch
                            seen.add(digest(patch))
                            grades.append(grade)
                            (directory / f"candidate_{len(grades)}.patch").write_text(patch)
                            event("grading", **grade)
                            remember('grading', call=tool_iteration, grade=grade, patch=patch)
                            result = {"grading": grade, "instruction":
                                "Counts only, not hidden test identities. If failing, identify what "
                                "your plan or scenario tracing missed, repair, build, submit again."}
                            passed = grade["tests_failed"] == 0
                            if not passed and len(grades) < cfg.max_evaluations:
                                latest_review = review(patch)
                                if latest_review:
                                    result['review'] = latest_review
                                    result['instruction'] += (
                                        " Independently verify the review against requirements/source. "
                                        "Apply supported repairs next; if evidence is missing, inspect only "
                                        "the named gap. Record the action or evidence-based rejection in notes.")
                        else:
                            raise ValueError(f"Unknown tool: {name}")
                    except BudgetExceeded:
                        raise
                    except DispatcherShutdown:
                        raise
                    except Exception as exc:
                        result = {"error": f"{type(exc).__name__}: {exc}"}
                    error = bool(result.get("error") or result.get("exit_code", 0) or result.get("timed_out")
                                 or any(item.get('error') for item in result.get('files', []) if isinstance(item, dict)))
                    if name in ('read_files', 'bash', 'build', 'list_files', 'search_files'):
                        observations.append({'call': calls, 'tool': name, 'arguments': args, 'result': result})
                    logger.tool_result(tool_iteration, name, result, error)
                    remember('tool_result', call=tool_iteration, tool=name, arguments=args,
                             result=result, is_error=error)
                    messages.append({"role": "tool", "tool_call_id": call["id"],
                                     "content": json.dumps(result, ensure_ascii=False)})
                if passed:
                    reason = "all grader tests passed"
                    break
                if len(grades) >= cfg.max_evaluations:
                    reason = "grading allowance reached"
                    break
        except DispatcherShutdown:
            raise
        except BudgetExceeded as exc:
            reason = str(exc)
        except Exception as exc:
            reason = f"worker error: {type(exc).__name__}: {exc}"
            event("worker_error", error=reason)
            _debug(f"task {key}: {reason}")
        # extract_patch can overwrite the dispatcher's patch file during tools.
        # Never let done() grade unsubmitted work: retain only the last graded patch.
        self.dispatcher.submit_patch(key, last_submitted)
        event("finished", reason=reason, calls=calls, grades=grades, budget=self.budget.snapshot(key))
        return self.dispatcher.done(key, reason=reason, iterations=calls)
