"""Coding agent with bounded file reads, context, recovery and grader feedback."""

import hashlib
import json
import os
import posixpath
import re
import shlex
import sys
import time
import traceback
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone

from .sandbox import Sandbox

WORKERS = 5
MAX_SOLVER_ITERATIONS = 200
MAX_EVALUATIONS = 10
MAX_OUTPUT_TOKENS = 16384
ASSESSMENT_OUTPUT_TOKENS = 256
MAX_BAD_TURNS = 3
MAX_REPEATED_COMMANDS = 4
MODEL_TIERS = ("starter", "standard", "expert")
SUBMIT_COMMAND = "echo COMPLETE_TASK_AND_SUBMIT_FINAL_OUTPUT"
READ_BATCH_FILES = 4
READ_DEFAULT_LINES = 200
READ_MAX_LINES = 500
READ_BATCH_CHARS = 20000
FILE_CACHE_CHARS = 30000
FILE_CACHE_RANGES = 12
CONTEXT_MAX_CHARS = 120000  # Harness soft budget, not a model context-token limit.
CONTEXT_RECENT_TURNS = 12
ACTION_WINDOW = 8
CYCLE_OCCURRENCES = 3

TOOLS = [{
    "type": "function",
    "function": {
        "name": "bash",
        "description": (
            "Execute a shell command in the task repository. Use it to inspect "
            "files, edit code, and run tests. You can batch related commands. "
            "Each call starts in the repository directory; cwd and environment "
            "changes do not persist. The shell is /bin/sh; invoke bash explicitly "
            "for Bash-specific syntax. Files do persist. There is no internet. "
            "Keep output focused. Finish only with the exact command: " + SUBMIT_COMMAND
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "command": {"type": "string", "minLength": 1},
                "timeout_s": {
                    "type": "integer", "minimum": 1, "maximum": 600, "default": 120,
                },
            },
            "required": ["command"],
            "additionalProperties": False,
        },
    },
}]
TOOLS += [
    {"type": "function", "function": {
        "name": "find_files",
        "description": "Find existing repository files by glob or basename. Use after a missing-file error; never guess paths.",
        "parameters": {"type": "object", "properties": {
            "pattern": {"type": "string", "minLength": 1},
        }, "required": ["pattern"], "additionalProperties": False},
    }},
    {"type": "function", "function": {
        "name": "read_files",
        "description": (
            "Read up to four repository files/ranges at once. Lines are 1-based. "
            "Returns numbered lines, file version, total lines and exact continuation. "
            "Prefer this to cat. Use next_start_line to continue a truncated range."
        ),
        "parameters": {"type": "object", "properties": {
            "requests": {"type": "array", "minItems": 1, "maxItems": READ_BATCH_FILES,
                "items": {"type": "object", "properties": {
                    "path": {"type": "string", "minLength": 1},
                    "start_line": {"type": "integer", "minimum": 1, "default": 1},
                    "num_lines": {"type": "integer", "minimum": 1, "maximum": READ_MAX_LINES,
                        "default": READ_DEFAULT_LINES},
                }, "required": ["path"], "additionalProperties": False}},
        }, "required": ["requests"], "additionalProperties": False},
    }},
]

# These scripts execute inside the task Sandbox, never the agent's filesystem.
FILE_SCAN_SCRIPT = '''import fnmatch, json, os, subprocess, sys
pattern = sys.argv[1]
r = subprocess.run(["git", "ls-files", "-z", "--cached", "--others", "--exclude-standard"],
                   capture_output=True, check=True, timeout=15)
paths = sorted(set(p.decode("utf-8", "replace") for p in r.stdout.split(b"\\0") if p))
matches = [p for p in paths if os.path.isfile(p) and
           (fnmatch.fnmatchcase(p, pattern) or fnmatch.fnmatchcase(os.path.basename(p), pattern))]
selected, size = [], 0
for path in matches:
    if len(selected) >= 200 or size + len(path) > 20000: break
    selected.append(path)
    size += len(path)
print(json.dumps({"paths": selected, "total_matches": len(matches), "truncated": len(selected)<len(matches)}))
'''
REPOSITORY_STATE_SCRIPT = '''import hashlib, json, pathlib, subprocess
def git(*args):
    return subprocess.run(["git", *args], capture_output=True, check=True, timeout=15).stdout
diff = git("diff", "--binary", "HEAD")
h = hashlib.sha256(diff)
for raw in sorted(git("ls-files", "-z", "--others", "--exclude-standard").split(b"\\0")):
    if not raw: continue
    p = pathlib.Path(raw.decode("utf-8", "surrogateescape"))
    h.update(raw)
    if p.is_symlink(): h.update(str(p.readlink()).encode())
    elif p.is_file():
        with p.open("rb") as f:
            for block in iter(lambda: f.read(65536), b""): h.update(block)
text = diff.decode("utf-8", "replace")
print(json.dumps({"revision": h.hexdigest(),
    "status": git("status", "--short").decode("utf-8", "replace")[:2000],
    "diff_excerpt": text[:6000], "diff_chars": len(text)}))
'''


def positive_integer(value, name, maximum):
    if type(value) is not int or not 1 <= value <= maximum:
        raise ValueError(f"{name} must be an integer between 1 and {maximum}")
    return value


class FileContext:
    """Task-local, bounded snapshots. Always read fresh data from the Sandbox."""
    def __init__(self):
        self.snippets = {}

    def read(self, sb, requests, remember=True):
        if not isinstance(requests, list) or not 1 <= len(requests) <= READ_BATCH_FILES:
            raise ValueError(f"requests must contain 1..{READ_BATCH_FILES} file ranges")
        files = []
        remaining = READ_BATCH_CHARS
        for request in requests:
            if not isinstance(request, dict) or set(request) - {"path", "start_line", "num_lines"}:
                raise ValueError("Each request must have path and optional start_line/num_lines")
            path = request.get("path")
            if not isinstance(path, str) or not path.strip():
                raise ValueError("path must be a nonempty string")
            root = sb.workdir.rstrip("/")
            if path.startswith(root + "/"):
                path = path[len(root) + 1:]
            path = posixpath.normpath(path)
            if path.startswith("/") or path in (".", "..") or path.startswith("../"):
                raise ValueError("Use a repository-relative path returned by find_files")
            start = positive_integer(request.get("start_line", 1), "start_line", 10000000)
            count = positive_integer(request.get("num_lines", READ_DEFAULT_LINES), "num_lines", READ_MAX_LINES)
            try:
                text = sb.read_text(path)
            except Exception as exc:
                files.append({"path": path, "error": str(exc),
                    "next_action": f"Use find_files with pattern {posixpath.basename(path)!r}; do not retry a guessed path."})
                continue
            version = hashlib.sha256(text.encode()).hexdigest()[:16]
            lines = text.splitlines()
            target_end = min(len(lines), start - 1 + count)
            selected = []
            for offset in range(start - 1, target_end):
                line = f"{offset + 1}: {lines[offset]}\n"
                if len(line) > remaining:
                    break  # Never silently chop a source line in half.
                selected.append(line)
                remaining -= len(line)
            end = start + len(selected) - 1
            incomplete = end < target_end
            item = {
                "path": path, "version": version, "start_line": start, "end_line": end,
                "total_lines": len(lines), "content": "".join(selected),
                "truncated": incomplete, "has_more": end < len(lines),
                "next_start_line": end + 1 if end < len(lines) else None,
            }
            if start > len(lines) + 1:
                item["error"] = f"start_line exceeds EOF; file has {len(lines)} lines"
            elif incomplete and not selected:
                item["warning"] = (
                    "No complete line fit the remaining batch budget. Read this file alone; "
                    "if its first requested line exceeds the full budget, use a targeted bash search."
                )
            files.append(item)
            if remember and selected:
                # Old versions cannot remain in the active snapshot cache.
                self.snippets = {k: v for k, v in self.snippets.items()
                    if k[0] != path or v["version"] == version}
                key = (path, start, count)
                self.snippets.pop(key, None)
                self.snippets[key] = item
                while (len(self.snippets) > FILE_CACHE_RANGES or
                    sum(len(v["content"]) for v in self.snippets.values()) > FILE_CACHE_CHARS):
                    self.snippets.pop(next(iter(self.snippets)))
        return {"files": files, "is_error": any(f.get("error") for f in files)}

    def refreshed_snippets(self, sb):
        refreshed = []
        # Refresh on compaction: shell commands may have changed or removed files.
        for path, start, count in list(self.snippets):
            result = self.read(sb, [{"path": path, "start_line": start, "num_lines": count}], remember=False)
            refreshed.extend(result["files"])
        self.snippets.clear()
        for item in refreshed:
            if item.get("content"):
                key = (item["path"], item["start_line"], item["end_line"] - item["start_line"] + 1)
                self.snippets[key] = item
        while (len(self.snippets) > FILE_CACHE_RANGES or
            sum(len(v["content"]) for v in self.snippets.values()) > FILE_CACHE_CHARS):
            self.snippets.pop(next(iter(self.snippets)))
        return list(self.snippets.values()) + [item for item in refreshed if item.get("error")]


def _debug(message):
    print(f"[madsOpt] {message}", file=sys.stderr, flush=True)


def call_model(client, model_id, messages, logger, iteration, **kwargs):
    """Log each returned completion; never retry without an output cap."""
    kwargs.setdefault("max_tokens", MAX_OUTPUT_TOKENS)
    started = time.monotonic()
    _debug(f"starting model={model_id}, iteration={iteration}")
    for attempt in range(2):
        try:
            response = client.chat.completions.create(
                model=model_id, messages=messages, **kwargs,
            )
        except Exception as exc:
            detail = str(exc)[:2000]
            _debug(f"model={model_id}, iteration={iteration}: {type(exc).__name__}: {detail}")
            if (
                attempt == 0 and getattr(exc, "status_code", None) == 400
                and "max_tokens" in kwargs and "max_tokens" in detail
                and any(word in detail.lower() for word in (
                    "unsupported", "not supported", "not compatible", "unrecognized",
                ))
            ):
                kwargs["max_completion_tokens"] = kwargs.pop("max_tokens")
                continue
            raise

        usage = getattr(response, "usage", None)
        logger.api_request(
            iteration,
            getattr(usage, "prompt_tokens", None),
            getattr(usage, "completion_tokens", None),
            getattr(usage, "total_tokens", None),
            model_id,
        )
        choices = getattr(response, "choices", None)
        if choices and getattr(choices[0], "message", None) is not None:
            _debug(
                f"model={model_id}, iteration={iteration} returned after "
                f"{time.monotonic() - started:.1f}s; finish_reason={choices[0].finish_reason}"
            )
            return response
        _debug(f"model={model_id}: empty completion; {'retrying once' if not attempt else 'stopping'}")
    raise RuntimeError(f"Course API returned no usable completion twice for model={model_id}")


def bounded_result(result):
    """Keep useful failure output without flooding the next model request."""
    output = result.get("output", "")
    if len(output) <= 10000:
        return result
    return {
        **result,
        "output": output[:5000] + "\n...[output truncated; narrow the command]...\n" + output[-5000:],
        "original_output_chars": len(output),
    }


class Agent:
    def __init__(self, dispatcher):
        from openai import OpenAI

        self.dispatcher = dispatcher
        self.models = {
            tier: os.environ[f"CS2680_MODEL_{tier.upper()}"]
            for tier in MODEL_TIERS
        }
        self.client = OpenAI(
            base_url=os.environ["CS2680_BASE_URL"],
            api_key=os.environ["CS2680_API_KEY"],
            timeout=120,
            max_retries=1,
        )

    def run(self):
        from dispatcher import DispatcherError, DispatcherShutdown

        def worker():
            while True:
                try:
                    task = self.dispatcher.next_task()
                except DispatcherShutdown:
                    return
                except DispatcherError as exc:
                    if "too many live tasks" not in str(exc).lower():
                        raise
                    time.sleep(1)
                    continue
                if task is None:
                    return
                task["_solver_iterations"] = 0
                try:
                    self.solve(task)
                except DispatcherShutdown:
                    return
                except Exception as exc:
                    _debug(f"task {task['task']}: {type(exc).__name__}: {exc}")
                    traceback.print_exc(file=sys.stderr)
                    # Preserve the latest edits even if an API request fails.
                    try:
                        self.dispatcher.extract_patch(task["task"])
                    except DispatcherShutdown:
                        return
                    except Exception as cleanup_exc:
                        _debug(f"could not extract patch after error: {cleanup_exc}")
                    try:
                        self.dispatcher.done(
                            task["task"], f"worker error: {type(exc).__name__}: {str(exc)[:300]}",
                            task["_solver_iterations"],
                        )
                    except DispatcherShutdown:
                        return

        with ThreadPoolExecutor(max_workers=max(1, min(WORKERS, 5))) as pool:
            futures = [pool.submit(worker) for _ in range(max(1, min(WORKERS, 5)))]
            for future in futures:
                future.result()

    def assess_task(self, task, logger):
        response = call_model(
            self.client, self.models["starter"],
            [
                {"role": "system", "content": (
                    'Estimate coding-task difficulty from 1 (trivial) to 100 (very hard). '
                    'Return only JSON: {"difficulty": integer}.'
                )},
                {"role": "user", "content": self.task_description(task)},
            ],
            logger, iteration=0, temperature=0, max_tokens=ASSESSMENT_OUTPUT_TOKENS,
        )
        try:
            choice = response.choices[0]
            if choice.finish_reason == "length":
                raise ValueError("Truncated assessment")
            text = choice.message.content or ""
            score = json.loads(text[text.index("{"):text.rindex("}") + 1])["difficulty"]
            return {"difficulty": max(1, min(100, int(score)))}
        except (ValueError, TypeError, KeyError):
            _debug(f"task {task['task']}: invalid difficulty; using 50")
            return {"difficulty": 50}

    def choose_policy(self, assessment):
        score = assessment["difficulty"]
        tier = "starter" if score <= 60 else "standard" if score <= 90 else "expert"
        return {
            "tier": tier, "model": self.models[tier],
            "max_iterations": MAX_SOLVER_ITERATIONS, "max_evaluations": MAX_EVALUATIONS,
            "bad_turns": 0, "last_command": None, "repeats": 0,
            "last_result": None,
            "files": FileContext(), "recent_actions": [], "repository_state": {},
            "grades": [], "plan_note": "", "compact_requested": False,
            "recovery_note": "",
        }

    def capture_repository_state(self, sb, logger, iteration, policy):
        """Small, read-only Sandbox snapshot; no extra model request."""
        logger.tool_call(iteration, "repository_state", {})
        try:
            result = sb.exec("python3 -c " + shlex.quote(REPOSITORY_STATE_SCRIPT), timeout_s=30)
            if result.get("exit_code", 0) != 0:
                raise ValueError(result.get("output", "git snapshot failed"))
            state = json.loads(result["output"])
            if not isinstance(state.get("revision"), str):
                raise ValueError("snapshot has no revision")
            old = policy["repository_state"].get("revision")
            if old is not None and old != state["revision"]:
                policy["recent_actions"].clear()
            policy["repository_state"] = state
            logger.tool_result(iteration, "repository_state", state, False)
        except Exception as exc:
            # A diagnostic failure must not turn a useful failing test into a
            # model protocol error. Normal tool execution still reports errors.
            logger.tool_result(iteration, "repository_state", {"error": str(exc)[:500]}, True)

    def compact_context(self, task, sb, policy, messages):
        """Deterministic compaction: keep roots and complete tool exchanges."""
        if len(messages) < 2 or messages[0]["role"] != "system":
            return
        size = len(json.dumps(messages, ensure_ascii=False))
        if not policy["compact_requested"] and size <= CONTEXT_MAX_CHARS:
            return
        roots = messages[:2]
        groups = []
        i = 2
        while i < len(messages):
            message = messages[i]
            if message.get("content", "") and message["role"] == "user" and str(message["content"]).startswith("Working-state snapshot:"):
                i += 1
                continue
            count = len(message.get("tool_calls", [])) if message["role"] == "assistant" else 0
            group = messages[i:i + 1 + count]
            if count and (
                len(group) != count + 1 or
                [m.get("tool_call_id") for m in group[1:]] != [t["id"] for t in message["tool_calls"]] or
                any(m["role"] != "tool" for m in group[1:])
            ):
                raise RuntimeError("Cannot compact an incomplete tool exchange")
            if message["role"] == "tool":
                raise RuntimeError("Cannot compact an orphan tool result")
            # Remove complete rejected-loop exchanges, not isolated tool results.
            rejected = False
            if count:
                try:
                    rejected = all(json.loads(m["content"]).get("loop_blocked") for m in group[1:])
                except (ValueError, TypeError, AttributeError):
                    pass
            if not rejected:
                groups.append(group)
            i += len(group)
        state = {
            "note": "Older exchanges were omitted, not undone. Files and edits persist. Historical reads may be outdated.",
            "latest_plan_or_action_note": policy["plan_note"],
            "grading_history": policy["grades"],
            "recovery_note": policy["recovery_note"],
            "repository": policy["repository_state"],
            "fresh_file_ranges": policy["files"].refreshed_snippets(sb),
        }
        summary = {"role": "user", "content": "Working-state snapshot:\n" + json.dumps(state, ensure_ascii=False)}
        recent = groups[-CONTEXT_RECENT_TURNS:]
        candidate = roots + [summary] + [m for group in recent for m in group]
        while len(json.dumps(candidate, ensure_ascii=False)) > CONTEXT_MAX_CHARS and len(recent) > 1:
            recent.pop(0)
            candidate = roots + [summary] + [m for group in recent for m in group]
        messages[:] = candidate
        policy["compact_requested"] = False
        _debug(f"task {task['task']}: context compacted {size} -> {len(json.dumps(messages, ensure_ascii=False))} characters")

    def escalate_solver(self, task, policy, messages, reason):
        """Move up at most two tiers, keeping the same task, history and budgets."""
        current = MODEL_TIERS.index(policy["tier"])
        for tier in MODEL_TIERS[current + 1:]:
            if self.models[tier] == policy["model"]:
                continue  # Aliases configured to the same model are not a fallback.
            _debug(f"task {task['task']}: escalating {policy['tier']} -> {tier}: {reason}")
            policy.update(
                tier=tier, model=self.models[tier], bad_turns=0,
                repeats=0, compact_requested=True,
            )
            policy["recovery_note"] = reason
            messages.append({"role": "user", "content": (
                f"Solver handoff after stalled progress: {reason}. "
                "The task repository and existing edits are unchanged. Relevant "
                "observations are retained or summarized. Review the requirements and actual source files, "
                "identify what is still missing, then implement and test a fix. "
                "Do not repeat the previous unproductive experiment or claim work "
                "was done without executing it. The original turn and grading "
                "budgets still apply."
            )})
            return True
        return False

    @staticmethod
    def task_description(task):
        return (
            f"Problem statement:\n{task['problem_statement']}\n\n"
            f"Requirements:\n{task['requirements']}\n\n"
            f"Interface:\n{task['interface']}"
        )

    def build_solver_messages(self, task, policy):
        return [
            {"role": "system", "content": (
                "You are a coding agent. Fix the issue using the repository tools.\n"
                f"Working directory: {task['workdir']}. Every command starts there. "
                "Shell cwd/environment changes do not persist; file edits do. No internet.\n"
                "1. Find and read the actual relevant implementation and nearby tests. "
                "Read the function bodies, not just imports. Search the repository if a "
                "symbol is absent from the first file; do not invent existing code.\n"
                "Use find_files to discover actual paths and read_files to batch relevant "
                "source/test ranges. Lines are 1-based. Follow next_start_line when a "
                "read is truncated. On a missing-file error, search before reading again; "
                "do not keep guessing or alternating invalid paths.\n"
                "2. After inspection, think of all corner cases implied by the issue, "
                "every requirement, and the actual code. Include boundary values, "
                "missing/empty inputs, invalid inputs, priority/ordering, combinations "
                "of conditions, and compatibility with existing behavior where relevant. "
                "Give a concise fix plan and corner-case test checklist. Create a general "
                "fix compliant with every corner case you identified, not just the "
                "visible example. Do not claim exhaustive coverage without evidence. "
                "Reproduce the failure or "
                "identify the missing behavior with a focused test. Inspect the repository "
                "test setup and use its installed interpreter/toolchain.\n"
                "3. Make the smallest general source change. Shell scripts can read/write "
                "multiple files in one call. Preserve unrelated code; do not change tests "
                "just to force success. Store temporary reproductions in /work.\n"
                "4. Run the reproduction and relevant tests. Create and execute focused "
                "tests for the identified corner cases and each requirement; update the "
                "checklist when new cases emerge. Inspect "
                "real exit codes and output, fix failures, and rerun tests after changes.\n"
                "5. Review git status --short, git diff --check, and git diff. Keep scratch "
                "files out of the patch. Do not commit; the dispatcher extracts the full diff.\n"
                "Use the tools for actual repository actions; prose alone does not read, edit, "
                "test, or submit anything. Keep analysis and plans brief, then take a "
                "concrete action. Reuse earlier results and correct failed commands "
                "instead of repeating them unchanged.\n"
                f"Each response has a {MAX_OUTPUT_TOKENS}-token output limit, including "
                "tool arguments. Send complete, focused commands. Batch related reads "
                "when useful, but split large edits across turns. Never pad output with "
                "whitespace or repeat a pipeline stage.\n"
                "Prefer small, precise edits. Run test commands without piping to grep, "
                "head or tail unless you preserve the test process's exit status. A "
                "successful filter is not evidence that tests passed. Earlier file "
                "observations are historical; refresh relevant ranges after edits.\n"
                f"Only when the patch and testing are complete, call bash with exactly:\n{SUBMIT_COMMAND}\n"
                "Issue that command alone. It submits the current patch for hidden grading; "
                "if grading fails, you can continue repairing the same repository."
            )},
            {"role": "user", "content": self.task_description(task)},
        ]

    def record_model_response(self, task, policy, iteration, choice):
        message = choice.message
        record = {
            "timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "iteration": iteration, "model_id": policy["model"],
            "finish_reason": choice.finish_reason, "content": message.content,
            "tool_calls": [
                {"id": tool.id, "name": tool.function.name, "arguments": tool.function.arguments}
                for tool in message.tool_calls or []
            ],
        }
        directory = os.path.join("madsOpt_logs", str(task["task"]))
        os.makedirs(directory, exist_ok=True)
        with open(os.path.join(directory, "model_responses.jsonl"), "a") as stream:
            stream.write(json.dumps(record, ensure_ascii=False) + "\n")

    def execute_tool(self, sb, logger, iteration, tool, allow_submit=True, files=None):
        name = tool.function.name
        try:
            arguments = json.loads(tool.function.arguments or "{}")
        except (ValueError, TypeError) as exc:
            arguments = {"raw": tool.function.arguments}
            logger.tool_call(iteration, name, arguments)
            result = {"error": f"Invalid JSON arguments: {exc}"}
            logger.tool_result(iteration, name, result, True)
            return result
        logger.tool_call(iteration, name, arguments)
        try:
            if not isinstance(arguments, dict):
                raise ValueError("Use only bash, find_files or read_files with JSON object arguments")
            if name == "find_files":
                pattern = arguments.get("pattern")
                if set(arguments) != {"pattern"} or not isinstance(pattern, str) or not pattern.strip() or len(pattern) > 256:
                    raise ValueError("find_files requires one nonempty pattern, at most 256 characters")
                response = sb.exec("python3 -c " + shlex.quote(FILE_SCAN_SCRIPT) + " " + shlex.quote(pattern), timeout_s=30)
                if response.get("exit_code", 0) != 0:
                    raise ValueError(response.get("output", "File discovery failed"))
                result = json.loads(response["output"])
                if not isinstance(result.get("paths"), list):
                    raise ValueError("File discovery returned invalid data")
                logger.tool_result(iteration, name, result, False)
                return result
            if name == "read_files":
                if set(arguments) != {"requests"}:
                    raise ValueError("read_files accepts requests only")
                result = (files if files is not None else FileContext()).read(sb, arguments["requests"])
                logger.tool_result(iteration, name, result, result["is_error"])
                return result
            if name != "bash":
                raise ValueError("Use only bash, find_files or read_files")
            if set(arguments) - {"command", "timeout_s"}:
                raise ValueError("bash accepts command and optional timeout_s only")
            command = arguments.get("command")
            if not isinstance(command, str) or not command.strip():
                raise ValueError("command must be a nonempty string")
            if command.strip() == SUBMIT_COMMAND:
                if not allow_submit:
                    raise ValueError("Submit in its own tool call, without other actions")
                result = {"submitted": True}
            else:
                timeout_s = max(1, min(int(arguments.get("timeout_s", 120)), 600))
                _debug(f"iteration {iteration}: bash {command[:200]!r}")
                result = sb.exec(command, timeout_s=timeout_s)
                if re.match(r"^\s*(?:cat|grep|sed|head|tail|nl|wc)\b", command) and "No such file or directory" in result.get("output", ""):
                    result = {**result, "error": "Requested file does not exist. Call find_files for repository paths, or use bash find for library/dependency paths. Locate the actual path before another read."}
        except Exception as exc:
            result = {"error": f"{type(exc).__name__}: {exc}"}
        failed = bool(result.get("error") or result.get("timed_out") or result.get("exit_code", 0) != 0)
        logger.tool_result(iteration, name, result, failed)
        return result

    def run_solver_turn(self, task, sb, logger, policy, messages, iteration):
        """Return True only on an explicit submit command."""
        if not policy["repository_state"]:
            self.capture_repository_state(sb, logger, iteration, policy)
        self.compact_context(task, sb, policy, messages)
        response = call_model(
            self.client, policy["model"], messages, logger, iteration,
            tools=TOOLS, tool_choice="auto", temperature=0,
        )
        choice = response.choices[0]
        self.record_model_response(task, policy, iteration, choice)
        message = choice.message
        tools = message.tool_calls or []
        if choice.finish_reason == "length":
            # A complete-looking JSON command may still be partial. Reject the
            # entire truncated response, and do not feed its repetition back.
            for tool in tools:
                logger.tool_call(iteration, tool.function.name, {"raw": tool.function.arguments})
                logger.tool_result(iteration, tool.function.name, {
                    "error": "Response truncated; tool was not executed", "executed": False,
                }, True)
            policy["bad_turns"] += 1
            messages.append({"role": "user", "content": (
                f"Your response reached the {MAX_OUTPUT_TOKENS}-token output limit. "
                "It was discarded; no commands or edits from that response were executed. "
                "Retry the next repository action with a short, complete bash tool call. "
                "Split large edits across turns. Do not repeat text, whitespace, or "
                "pipeline stages."
            )})
            if policy["bad_turns"] >= MAX_BAD_TURNS and not self.escalate_solver(
                task, policy, messages, "repeated truncated responses",
            ):
                raise RuntimeError("Model repeatedly returned truncated or non-actionable responses")
            return False
        if choice.finish_reason not in ("stop", "tool_calls"):
            raise RuntimeError(f"Unexpected finish reason: {choice.finish_reason}")
        if message.content and message.content.strip() and (
            not policy["plan_note"] or any(word in message.content.lower() for word in ("corner", "plan", "requirement", "checklist"))
        ):
            policy["plan_note"] = message.content[:4000]
        if not tools:
            # Automatic tool selection permits an ordinary analysis/plan turn.
            # Preserve it so the next request can act on the model's own plan.
            if message.content and message.content.strip():
                messages.append({"role": "assistant", "content": bounded_result({
                    "output": message.content,
                })["output"]})
            messages.append({"role": "user", "content": (
                "No repository action was executed. Use find_files, read_files or bash now to carry out "
                "the next step of your plan. A text description is not a file edit or "
                "test result. To submit a tested patch, use the exact submit command."
            )})
            policy["bad_turns"] += 1
            if policy["bad_turns"] >= MAX_BAD_TURNS and not self.escalate_solver(
                task, policy, messages, "repeated responses without repository actions",
            ):
                raise RuntimeError("Model repeatedly returned truncated or non-actionable responses")
            return False
        messages.append({
            "role": "assistant", "content": message.content,
            "tool_calls": [
                {"id": tool.id, "type": "function", "function": {
                    "name": tool.function.name, "arguments": tool.function.arguments,
                }}
                for tool in tools
            ],
        })
        submitted = False
        failed = 0
        repeated = False
        for tool in tools:
            try:
                arguments = json.loads(tool.function.arguments or "{}")
                command = arguments.get("command") if isinstance(arguments, dict) else None
                command = command.strip() if isinstance(command, str) else None
            except (ValueError, TypeError):
                arguments = None
                command = None
            duplicate = False
            key = None
            previous = None
            if isinstance(arguments, dict):
                canonical = dict(arguments)
                if tool.function.name == "bash" and command:
                    canonical = {"command": command}
                key = tool.function.name + ":" + json.dumps(canonical, sort_keys=True, ensure_ascii=False)
                previous = next((a["result"] for a in reversed(policy["recent_actions"]) if a["key"] == key), None)
            cycle = key is not None and sum(a["key"] == key for a in policy["recent_actions"]) >= CYCLE_OCCURRENCES - 1
            if tool.function.name == "bash" and command and command != SUBMIT_COMMAND:
                duplicate = command == policy["last_command"]
                policy["repeats"] = policy["repeats"] + 1 if duplicate else 1
                policy["last_command"] = command
            # Always refresh read_files so changes, even to ignored files, can be
            # observed. A different file version is not the same repeated read.
            if tool.function.name == "read_files":
                cycle = False
            if duplicate or cycle:
                # Return feedback before another identical command can run.
                # Re-running a write or side-effecting command is not safe.
                logger.tool_call(iteration, tool.function.name, arguments)
                result = {
                    "error": (
                        "Repeated command blocked: this exact command already ran. "
                        "Use the previous result below; do not run it again unchanged. "
                        "Take a different action: read the relevant repository source, "
                        "edit it to address the requirements, or run a focused test "
                        "after making a change."
                    ),
                    "executed": False,
                    "loop_blocked": True,
                    "previous_result": previous if previous is not None else policy["last_result"],
                }
                logger.tool_result(iteration, tool.function.name, result, True)
                repeated = repeated or policy["repeats"] >= MAX_REPEATED_COMMANDS
                if cycle:
                    policy["compact_requested"] = True
                policy["recovery_note"] = result["error"]
            else:
                result = self.execute_tool(sb, logger, iteration, tool,
                    allow_submit=len(tools) == 1, files=policy["files"])
                if tool.function.name == "bash" and command and command != SUBMIT_COMMAND:
                    policy["last_result"] = bounded_result(result)
                    self.capture_repository_state(sb, logger, iteration, policy)
                if tool.function.name == "read_files" and key is not None:
                    versions = [f.get("version", f.get("error")) for f in result.get("files", [])]
                    key += ":" + json.dumps(versions, ensure_ascii=False)
                    if sum(a["key"] == key for a in policy["recent_actions"]) >= CYCLE_OCCURRENCES - 1:
                        result = {**result, "error": "Repeated unchanged file ranges. Use a different range or proceed to the fix.", "loop_blocked": True}
                        policy["compact_requested"] = True
                        policy["recovery_note"] = result["error"]
                        logger.tool_call(iteration, "loop_recovery", {"tool": "read_files"})
                        logger.tool_result(iteration, "loop_recovery", {"error": result["error"]}, True)
            if key is not None and not result.get("submitted"):
                cached = result.get("previous_result") if result.get("loop_blocked") and "previous_result" in result else bounded_result(result)
                policy["recent_actions"].append({"key": key, "result": cached})
                del policy["recent_actions"][:-ACTION_WINDOW]
            messages.append({
                "role": "tool", "tool_call_id": tool.id,
                "content": json.dumps(bounded_result(result), ensure_ascii=False, default=str),
            })
            submitted = bool(result.get("submitted"))
            # Failing tests are useful feedback, not malformed model actions.
            # Only tool/protocol errors count toward the bad-turn stop rule.
            failed += bool(result.get("error") or result.get("is_error"))
        policy["bad_turns"] = policy["bad_turns"] + 1 if failed == len(tools) else 0
        if repeated or policy["bad_turns"] >= MAX_BAD_TURNS:
            reason = (
                "Model repeated the same shell command without an intervening action"
                if repeated else "Model repeatedly failed to execute useful shell actions"
            )
            if not self.escalate_solver(task, policy, messages, reason):
                raise RuntimeError(reason + "; no stronger model tier remains")
        return submitted

    def solve(self, task):
        k = task["task"]
        task["_solver_iterations"] = 0
        logger = self.dispatcher.logger(k)
        sb = Sandbox(task["sandbox_url"], task["workdir"])
        policy = self.choose_policy(self.assess_task(task, logger))
        messages = self.build_solver_messages(task, policy)
        _debug(f"task {k}: tier={policy['tier']}, turns={policy['max_iterations']}, evaluations={policy['max_evaluations']}")
        iterations = evaluations = 0
        empty_submissions = 0
        reason = "iteration budget exhausted"
        while iterations < policy["max_iterations"]:
            remaining = policy["max_iterations"] - iterations
            slots = policy["max_evaluations"] - evaluations
            checkpoint = iterations + (remaining + slots - 1) // slots
            messages.append({"role": "user", "content": (
                f"{checkpoint - iterations} turns until the next grading checkpoint. "
                "Read the relevant implementation, make a real patch, run tests, then submit."
            )})
            submitted = False
            while iterations < checkpoint:
                iterations += 1
                task["_solver_iterations"] = iterations
                submitted = self.run_solver_turn(task, sb, logger, policy, messages, iterations)
                if submitted:
                    break
            size = self.dispatcher.extract_patch(k)
            if not size:
                reason = "no patch"
                empty_submissions += int(submitted)
                if empty_submissions >= MAX_BAD_TURNS:
                    reason = "repeated submission without a patch"
                    if not self.escalate_solver(task, policy, messages, reason):
                        break
                    empty_submissions = 0
                messages.append({"role": "user", "content": (
                    "The cumulative diff is empty. No implementation has been submitted. "
                    "Read the relevant source, make an actual change, and test it before submitting."
                )})
                continue
            verdict = self.dispatcher.evaluate(k)
            evaluations += 1
            previous_grade = policy["grades"][-1] if policy["grades"] else None
            policy["grades"].append(dict(verdict))
            _debug(f"task {k}: evaluation {evaluations}: {verdict['tests_failed']}/{verdict['tests_total']} failing")
            if verdict["tests_failed"] == 0:
                reason = "passed"
                break
            reason = "evaluation budget exhausted" if evaluations >= policy["max_evaluations"] else "iteration budget exhausted"
            if evaluations >= policy["max_evaluations"] or iterations >= policy["max_iterations"]:
                break
            self.dispatcher.continue_task(k)
            policy["bad_turns"] = policy["repeats"] = 0
            policy["last_command"] = None
            policy["last_result"] = None
            policy["recent_actions"].clear()
            messages.append({"role": "user", "content": (
                f"Hidden evaluation attempt {verdict['attempt']}: "
                f"{verdict['tests_failed']} of {verdict['tests_total']} tests failed. "
                "Hidden test names and failure details are unavailable. The repository, "
                "your edits, and this conversation persist. Review the requirements and "
                "current diff, add focused tests for missed edge cases, and repair the code. "
                "Reconsider all corner cases implied by each requirement and your "
                "inspected implementation, and make the fix comply with those cases. "
                "Rerun tests and submit again. Do not simply resubmit the same patch."
            )})
            if (previous_grade is not None and
                verdict["tests_total"] == previous_grade["tests_total"] and
                verdict["tests_failed"] >= previous_grade["tests_failed"]):
                self.escalate_solver(task, policy, messages,
                    f"grading did not improve: {previous_grade['tests_failed']}/{previous_grade['tests_total']} "
                    f"then {verdict['tests_failed']}/{verdict['tests_total']}; equal counts do not identify which tests failed")
        self.dispatcher.done(k, reason, iterations)
